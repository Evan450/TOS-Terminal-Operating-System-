-- ╔══════════════════════════════════════╗
-- ║  TOS Module: tape-storage            ║
-- ║  Data storage on Computronics tapes  ║
-- ╚══════════════════════════════════════╝
-- Provides file archival, restore, hex dump, and raw I/O
-- for Computronics tape drives used as data storage media.
--
-- Tape data format (per archived entry):
--   [4]  Magic      "TOS\x01"
--   [1]  Version    0x01
--   [1]  Flags      bit 0 = directory entry (no data)
--   [2]  Path len   uint16 big-endian
--   [N]  Path       UTF-8 path string
--   [4]  Data len   uint32 big-endian  (0 for dirs)
--   [4]  Checksum   CRC-like sum of data bytes
--   [D]  Data       raw file bytes
-- End-of-archive marker: "TOS\x00" (4 bytes)

local component = require("component")
local computer   = require("computer")
local fs         = require("kernel.fs")

local mod = {}

-- ── Constants ────────────────────────────────────────────
local MAGIC     = "TOS\x01"
local EOA       = "TOS\x00"  -- end of archive
local VERSION   = 1
local FLAG_DIR  = 1
local BLOCK     = 8192        -- R/W chunk size

-- ── Helpers ──────────────────────────────────────────────

--- Find the first tape_drive component, or a specific one by partial address.
local function findDrive(addr)
  if addr then
    for a in component.list("tape_drive") do
      if a:sub(1, #addr) == addr then
        return component.proxy(a)
      end
    end
    return nil, "No tape drive matching: " .. addr
  end
  local a = component.list("tape_drive")()
  if a then return component.proxy(a) end
  return nil, "No tape drive found"
end

--- Encode uint16 big-endian.
local function enc16(n)
  return string.char(math.floor(n / 256) % 256, n % 256)
end
--- Decode uint16 big-endian.
local function dec16(s)
  return s:byte(1) * 256 + s:byte(2)
end
--- Encode uint32 big-endian.
local function enc32(n)
  local b1 = math.floor(n / 16777216) % 256
  local b2 = math.floor(n / 65536) % 256
  local b3 = math.floor(n / 256) % 256
  local b4 = n % 256
  return string.char(b1, b2, b3, b4)
end
--- Decode uint32 big-endian.
local function dec32(s)
  return s:byte(1) * 16777216 + s:byte(2) * 65536 + s:byte(3) * 256 + s:byte(4)
end

--- Simple checksum (sum of all bytes mod 2^32).
local function checksum(data)
  local sum = 0
  for i = 1, #data do
    sum = (sum + data:byte(i)) % 4294967296
  end
  return sum
end

--- Read exactly n bytes from tape. Returns string or nil.
local function tapeRead(drive, n)
  local parts = {}
  local remaining = n
  while remaining > 0 do
    local chunk = drive.read(math.min(remaining, BLOCK))
    if not chunk or #chunk == 0 then return nil end
    parts[#parts + 1] = chunk
    remaining = remaining - #chunk
  end
  return table.concat(parts)
end

--- Write string to tape.
local function tapeWrite(drive, data)
  local written = 0
  while written < #data do
    local chunk = data:sub(written + 1, written + BLOCK)
    drive.write(chunk)
    written = written + #chunk
  end
end

--- Rewind tape to position 0.
local function rewind(drive)
  drive.seek(-drive.getSize())
end

--- Seek to an absolute position.
local function seekTo(drive, pos)
  rewind(drive)
  if pos > 0 then
    drive.seek(pos)
  end
end

--- Format byte count for display.
local function fmtSize(n)
  if n >= 1048576 then
    return string.format("%.1fMB", n / 1048576)
  elseif n >= 1024 then
    return string.format("%.1fKB", n / 1024)
  end
  return n .. "B"
end

--- Estimate tape length in minutes from byte capacity.
-- Computronics manual: storage ≈ (minutes / 4) MB
-- So: minutes ≈ bytes / 262144
local function tapeMinutes(sizeBytes)
  return sizeBytes / 262144
end

--- Format a tape capacity summary line.
local function fmtCapacity(size)
  local mins = tapeMinutes(size)
  if mins >= 1 then
    return string.format("%s (%d-minute tape)", fmtSize(size), math.floor(mins + 0.5))
  end
  return fmtSize(size)
end

--- Per-entry header overhead: 4 magic + 1 ver + 1 flags + 2 pathlen + 4 datalen + 4 checksum = 16 bytes + path length
local HEADER_FIXED = 16
--- End-of-archive marker size
local EOA_SIZE = 4

--- Calculate the total on-tape size for one entry (header + data).
local function entryTapeSize(pathLen, dataLen)
  return HEADER_FIXED + pathLen + dataLen
end

--- Scan the archive on tape and return { used = bytes, files = N, dirs = N, dataBytes = N }
--- Leaves the drive rewound to position 0.
local function scanArchive(drive)
  rewind(drive)
  local info = { used = 0, files = 0, dirs = 0, dataBytes = 0 }

  while true do
    local magic = tapeRead(drive, 4)
    if not magic or #magic < 4 then break end
    if magic == EOA then
      info.used = info.used + EOA_SIZE
      break
    end
    if magic ~= MAGIC then break end

    local verFlag = tapeRead(drive, 2)
    if not verFlag then break end
    local flags = verFlag:byte(2)

    local pathLenRaw = tapeRead(drive, 2)
    if not pathLenRaw then break end
    local pathLen = dec16(pathLenRaw)

    local relPath = tapeRead(drive, pathLen)
    if not relPath then break end

    local dataLenRaw = tapeRead(drive, 4)
    if not dataLenRaw then break end
    local dataLen = dec32(dataLenRaw)

    -- Skip checksum
    tapeRead(drive, 4)

    local isDir = (flags % 2) == 1
    local overhead = HEADER_FIXED + pathLen

    if isDir then
      info.dirs = info.dirs + 1
      info.used = info.used + overhead
    else
      info.files = info.files + 1
      info.dataBytes = info.dataBytes + dataLen
      info.used = info.used + overhead + dataLen
    end

    -- Skip data
    if dataLen > 0 then
      drive.seek(dataLen)
    end

    -- Yield periodically
    if (info.files + info.dirs) % 10 == 0 then
      computer.pullSignal(0)
    end
  end

  rewind(drive)
  return info
end

-- ── Subcommands ──────────────────────────────────────────

--- tape detect — list all tape drives and tape status
local function cmdDetect(args, o)
  local count = 0
  for addr in component.list("tape_drive") do
    count = count + 1
    local drive = component.proxy(addr)
    local ready = drive.isReady()
    local label = ready and (drive.getLabel() or "(unlabeled)") or "(no tape)"
    local state = drive.getState()
    o(string.format(" %d. %s", count, addr:sub(1, 8)), 0xFFFF00)
    if ready then
      local size = drive.getSize()
      o(string.format("    Label: %s  Capacity: %s  State: %s",
        label, fmtCapacity(size), state), 0xFFFFFF)
    else
      o(string.format("    %s  State: %s", label, state), 0xFFFFFF)
    end
  end
  if count == 0 then
    o("No tape drives found.", 0xFF6600)
    o("Install a Computronics Tape Drive to use this module.", 0xAAAAAA)
  end
end

--- tape info — detailed info about the current tape
local function cmdInfo(args, o)
  local drive, err = findDrive(args[2])
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted in drive " .. drive.address:sub(1, 8), 0xFF6600); return
  end
  local size = drive.getSize()
  local mins = tapeMinutes(size)
  o(" Tape Drive Info", 0xFFFF00)
  o("  Address:  " .. drive.address:sub(1, 8), 0xFFFFFF)
  o("  Label:    " .. (drive.getLabel() or "(none)"), 0xFFFFFF)
  o("  Capacity: " .. fmtCapacity(size), 0xFFFFFF)
  o("  Bytes:    " .. size, 0xAAAAAA)
  o("  State:    " .. drive.getState(), 0xFFFFFF)
  -- Check if tape has a TOS archive and scan usage
  rewind(drive)
  local header = tapeRead(drive, 4)
  rewind(drive)
  if header == MAGIC then
    o("  Format:   TOS archive", 0x00FF00)
    -- Scan to get usage stats
    local info = scanArchive(drive)
    local free = size - info.used
    local pctUsed = info.used * 100 / size
    o("", 0xFFFFFF)
    o("  Archive:", 0xFFFF00)
    o(string.format("    Files:    %d files, %d directories", info.files, info.dirs), 0xFFFFFF)
    o(string.format("    Data:     %s (file content)", fmtSize(info.dataBytes)), 0xFFFFFF)
    o(string.format("    Overhead: %s (headers + index)", fmtSize(info.used - info.dataBytes)), 0xAAAAAA)
    o(string.format("    Used:     %s (%.1f%%)", fmtSize(info.used), pctUsed), 0xFFFFFF)
    o(string.format("    Free:     %s (%.1f%%)", fmtSize(free), 100 - pctUsed),
      free < size * 0.1 and 0xFF6600 or 0x00FF00)
  elseif header == EOA then
    o("  Format:   TOS archive (empty)", 0xAAAAAA)
    local free = size - EOA_SIZE
    o(string.format("  Free:     %s (entire tape)", fmtSize(free)), 0x00FF00)
  elseif header then
    o("  Format:   Unknown / raw data", 0xAAAAAA)
    o("  Use 'tape dump 0 64' to inspect contents.", 0xAAAAAA)
  else
    o("  Format:   Blank", 0xAAAAAA)
    o(string.format("  Free:     %s (entire tape)", fmtSize(size)), 0x00FF00)
  end
end

--- tape label [name] — get or set tape label
local function cmdLabel(args, o)
  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end
  if args[2] then
    local name = table.concat(args, " ", 2)
    drive.setLabel(name)
    o("Label set: " .. name, 0x00FF00)
  else
    local lbl = drive.getLabel()
    if lbl and lbl ~= "" then
      o("Current label: " .. lbl, 0xFFFFFF)
    else
      o("Tape has no label. Use: tape label <name>", 0xAAAAAA)
    end
  end
end

--- tape store <path> [--overwrite] — archive a file or directory to tape
local function cmdStore(args, o)
  local path = args[2]
  if not path then
    o("Usage: tape store <path> [--overwrite]", 0xAAAAAA)
    o("  Archives a file or directory to the tape.", 0xAAAAAA)
    o("  Appends after existing archive data by default.", 0xAAAAAA)
    o("  Use --overwrite to replace the entire archive.", 0xAAAAAA)
    return
  end

  -- Parse flags and path from args (args[1] is the subcommand "store")
  local overwrite = false
  local pathArg = nil
  for i = 2, #args do
    if args[i] == "--overwrite" then
      overwrite = true
    else
      pathArg = args[i]
    end
  end
  if pathArg then path = pathArg end
  if not path or path == "" then
    o("Usage: tape store <path> [--overwrite]", 0xAAAAAA); return
  end

  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  drive.stop()

  -- Collect all files to archive
  path = fs.normalize(path)
  if not fs.exists(path) then
    o("Path not found: " .. path, 0xFF0000); return
  end

  local entries = {}  -- { path = string, isDir = bool }
  local basePath = path

  local function scan(dir)
    entries[#entries + 1] = { path = dir, isDir = true }
    local list = fs.list(dir)
    if not list then return end
    for _, name in ipairs(list) do
      local full = fs.join(dir, name)
      if fs.isDirectory(full) then
        scan(full)
      else
        entries[#entries + 1] = { path = full, isDir = false }
      end
    end
  end

  if fs.isDirectory(path) then
    scan(path)
  else
    entries[#entries + 1] = { path = path, isDir = false }
    basePath = fs.split(path) or "/"
  end

  -- ── Find append position ────────────────────────────────
  -- By default, scan existing archive and append after it.
  -- With --overwrite, start from position 0.
  local tapeSize = drive.getSize()
  local appendPos = 0
  local existingUsed = 0  -- bytes used by existing data (excluding old EOA)

  if not overwrite then
    rewind(drive)
    local headerCheck = tapeRead(drive, 4)
    rewind(drive)
    if headerCheck == MAGIC then
      local info = scanArchive(drive)
      if info.used > EOA_SIZE then
        existingUsed = info.used - EOA_SIZE  -- bytes before the old EOA marker
        appendPos = existingUsed
        o(string.format("Existing archive: %d files, %d dirs (%s)",
          info.files, info.dirs, fmtSize(info.used)), 0x00AAFF)
        o("Appending after existing entries...", 0xAAAAAA)
      end
    elseif headerCheck == EOA then
      -- Empty archive, just overwrite the EOA marker at position 0
      existingUsed = 0
      appendPos = 0
    end
  end

  -- ── Pre-write estimate ──────────────────────────────────
  -- Calculate total bytes needed before writing anything.
  local estimatedBytes = EOA_SIZE  -- always need the end marker
  local estimateFiles = 0
  local estimateData = 0
  for _, entry in ipairs(entries) do
    local relPath = entry.path
    if #basePath > 1 and relPath:sub(1, #basePath) == basePath then
      relPath = relPath:sub(#basePath + 1)
      if relPath == "" then relPath = "/" end
    end
    if entry.isDir then
      estimatedBytes = estimatedBytes + entryTapeSize(#relPath, 0)
    else
      local sz = fs.size(entry.path) or 0
      estimatedBytes = estimatedBytes + entryTapeSize(#relPath, sz)
      estimateData = estimateData + sz
      estimateFiles = estimateFiles + 1
    end
  end

  local availableSpace = tapeSize - existingUsed

  o(string.format("Archiving %d entries from %s", #entries, path), 0x00AAFF)
  o(string.format("  New data size:  %s (%s data + %s overhead)",
    fmtSize(estimatedBytes),
    fmtSize(estimateData),
    fmtSize(estimatedBytes - estimateData - EOA_SIZE)), 0xAAAAAA)
  if existingUsed > 0 then
    o(string.format("  Existing data:  %s", fmtSize(existingUsed)), 0xAAAAAA)
  end
  o(string.format("  Tape capacity:  %s", fmtCapacity(tapeSize)), 0xAAAAAA)

  if estimatedBytes > availableSpace then
    local over = estimatedBytes - availableSpace
    o(string.format("  WARNING: Data exceeds available space by %s!", fmtSize(over)), 0xFF6600)
    o("  Some files will not fit. Writing what we can...", 0xFF6600)
  else
    local afterFree = availableSpace - estimatedBytes
    local totalUsed = existingUsed + estimatedBytes
    o(string.format("  After write:    %s free (%.1f%% used)",
      fmtSize(afterFree), totalUsed * 100 / tapeSize), 0x00FF00)
  end
  o("", 0xFFFFFF)

  -- ── Write ───────────────────────────────────────────────
  -- Seek to the append position (after existing data, or position 0 for overwrite)
  seekTo(drive, appendPos)
  local totalBytes = 0
  local fileCount = 0

  for _, entry in ipairs(entries) do
    -- Make path relative to the base
    local relPath = entry.path
    if #basePath > 1 and relPath:sub(1, #basePath) == basePath then
      relPath = relPath:sub(#basePath + 1)
      if relPath == "" then relPath = "/" end
    end

    local flags = entry.isDir and FLAG_DIR or 0
    local data = ""
    if not entry.isDir then
      data = fs.readFile(entry.path) or ""
      fileCount = fileCount + 1
    end

    -- Build header
    local pathBytes = relPath
    local header = MAGIC
      .. string.char(VERSION)
      .. string.char(flags)
      .. enc16(#pathBytes)
      .. pathBytes
      .. enc32(#data)
      .. enc32(checksum(data))

    -- Check space (account for existing data + what we've written so far)
    local needed = #header + #data
    if existingUsed + totalBytes + needed + EOA_SIZE > tapeSize then
      o("WARNING: Tape full after " .. fileCount .. " files.", 0xFF6600)
      break
    end

    tapeWrite(drive, header)
    if #data > 0 then
      tapeWrite(drive, data)
    end
    totalBytes = totalBytes + needed

    -- Yield periodically to avoid "too long without yielding"
    if fileCount % 5 == 0 then
      computer.pullSignal(0)
    end
  end

  -- Write end-of-archive marker
  tapeWrite(drive, EOA)
  totalBytes = totalBytes + EOA_SIZE

  rewind(drive)
  local totalOnTape = existingUsed + totalBytes
  local freeAfter = tapeSize - totalOnTape
  o(string.format("Done: %d files, %s written", fileCount, fmtSize(totalBytes)), 0x00FF00)
  o(string.format("Tape: %s free (%.1f%% used)",
    fmtSize(freeAfter), totalOnTape * 100 / tapeSize),
    freeAfter < tapeSize * 0.1 and 0xFF6600 or 0x00FF00)
end

--- tape restore [path] [--addr=X] — restore archived files from tape
local function cmdRestore(args, o)
  local destBase = args[2] or "/home"
  destBase = fs.normalize(destBase)

  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  drive.stop()
  rewind(drive)

  o("Restoring from tape to " .. destBase .. " ...", 0x00AAFF)

  local fileCount = 0
  local dirCount = 0
  local totalBytes = 0

  while true do
    -- Read magic
    local magic = tapeRead(drive, 4)
    if not magic or #magic < 4 then
      o("Unexpected end of tape", 0xFF6600)
      break
    end

    -- Check for end-of-archive
    if magic == EOA then
      break
    end

    if magic ~= MAGIC then
      o("Not a TOS archive (bad magic at byte " .. totalBytes .. ")", 0xFF0000)
      rewind(drive)
      return
    end

    -- Read rest of header
    local verFlag = tapeRead(drive, 2)
    if not verFlag then o("Truncated header", 0xFF0000); break end
    local ver   = verFlag:byte(1)
    local flags = verFlag:byte(2)

    if ver > VERSION then
      o("Archive version " .. ver .. " not supported (max " .. VERSION .. ")", 0xFF0000)
      rewind(drive)
      return
    end

    local pathLenRaw = tapeRead(drive, 2)
    if not pathLenRaw then o("Truncated header", 0xFF0000); break end
    local pathLen = dec16(pathLenRaw)

    local relPath = tapeRead(drive, pathLen)
    if not relPath then o("Truncated path", 0xFF0000); break end

    local dataLenRaw = tapeRead(drive, 4)
    if not dataLenRaw then o("Truncated header", 0xFF0000); break end
    local dataLen = dec32(dataLenRaw)

    local cksumRaw = tapeRead(drive, 4)
    if not cksumRaw then o("Truncated header", 0xFF0000); break end
    local expectedSum = dec32(cksumRaw)

    totalBytes = totalBytes + 4 + 2 + 2 + pathLen + 4 + 4

    local isDir = (flags % 2) == 1
    local fullPath = fs.join(destBase, relPath)

    if isDir then
      if not fs.exists(fullPath) then
        fs.makeDirectory(fullPath)
      end
      dirCount = dirCount + 1
    else
      -- Read file data
      local data = ""
      if dataLen > 0 then
        data = tapeRead(drive, dataLen)
        if not data then
          o("Truncated data for: " .. relPath, 0xFF0000)
          break
        end
      end
      totalBytes = totalBytes + dataLen

      -- Verify checksum
      local actualSum = checksum(data)
      if actualSum ~= expectedSum then
        o("CHECKSUM MISMATCH: " .. relPath, 0xFF6600)
        o("  Expected: " .. expectedSum .. " Got: " .. actualSum, 0xFF6600)
        -- Still write it, but warn
      end

      -- Ensure parent directory exists
      local parentDir = fs.split(fullPath)
      if parentDir and parentDir ~= "/" and not fs.exists(parentDir) then
        fs.makeDirectory(parentDir)
      end

      fs.writeFile(fullPath, data)
      fileCount = fileCount + 1
    end

    -- Yield periodically
    if (fileCount + dirCount) % 5 == 0 then
      computer.pullSignal(0)
    end
  end

  rewind(drive)
  local tapeSize = drive.getSize()
  o(string.format("Restored: %d files, %d dirs (%s read from %s tape)",
    fileCount, dirCount, fmtSize(totalBytes), fmtCapacity(tapeSize)), 0x00FF00)
end

--- tape list — list files in a TOS tape archive
local function cmdList(args, o)
  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  local tapeSize = drive.getSize()
  drive.stop()
  rewind(drive)

  local magic = tapeRead(drive, 4)
  if magic == EOA then
    o("Tape archive is empty.", 0xAAAAAA)
    o(string.format("Tape: %s available (%s)", fmtSize(tapeSize - EOA_SIZE), fmtCapacity(tapeSize)), 0x00FF00)
    rewind(drive)
    return
  end
  if magic ~= MAGIC then
    o("Tape does not contain a TOS archive.", 0xFF6600)
    o("Use 'tape dump 0 64' to inspect raw data.", 0xAAAAAA)
    rewind(drive)
    return
  end

  -- Rewind and scan all entries
  rewind(drive)

  o(string.format(" %-6s  %-8s  %s", "Type", "Size", "Path"), 0xFFFF00)
  o(string.rep("-", 40), 0xAAAAAA)

  local fileCount = 0
  local dirCount = 0
  local totalData = 0
  local totalUsed = 0  -- total bytes on tape (headers + data + EOA)

  while true do
    local hdrMagic = tapeRead(drive, 4)
    if not hdrMagic or hdrMagic == EOA then
      totalUsed = totalUsed + EOA_SIZE
      break
    end
    if hdrMagic ~= MAGIC then break end

    local verFlag = tapeRead(drive, 2)
    if not verFlag then break end
    local flags = verFlag:byte(2)

    local pathLenRaw = tapeRead(drive, 2)
    if not pathLenRaw then break end
    local pathLen = dec16(pathLenRaw)

    local relPath = tapeRead(drive, pathLen)
    if not relPath then break end

    local dataLenRaw = tapeRead(drive, 4)
    if not dataLenRaw then break end
    local dataLen = dec32(dataLenRaw)

    -- Skip checksum
    tapeRead(drive, 4)

    local isDir = (flags % 2) == 1
    local entryOverhead = HEADER_FIXED + pathLen

    if isDir then
      o(string.format(" %-6s  %-8s  %s", "DIR", "", relPath), 0x55FF55)
      dirCount = dirCount + 1
      totalUsed = totalUsed + entryOverhead
    else
      o(string.format(" %-6s  %-8s  %s", "FILE", fmtSize(dataLen), relPath), 0xFFFFFF)
      fileCount = fileCount + 1
      totalData = totalData + dataLen
      totalUsed = totalUsed + entryOverhead + dataLen
    end

    -- Skip data
    if dataLen > 0 then
      drive.seek(dataLen)
    end

    if (fileCount + dirCount) % 10 == 0 then
      computer.pullSignal(0)
    end
  end

  rewind(drive)

  local free = tapeSize - totalUsed
  local pctUsed = totalUsed * 100 / tapeSize
  local overhead = totalUsed - totalData - EOA_SIZE

  o("", 0xFFFFFF)
  o(string.format(" %d files, %d dirs | %s data + %s overhead",
    fileCount, dirCount, fmtSize(totalData), fmtSize(overhead)), 0xAAAAAA)
  o(string.format(" Tape: %s used (%.1f%%) | %s free",
    fmtSize(totalUsed), pctUsed, fmtSize(free)),
    free < tapeSize * 0.1 and 0xFF6600 or 0x00FF00)
end

--- tape erase — wipe the tape (fill with zeros)
local function cmdErase(args, o)
  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  -- Quick erase: just write the EOA marker at position 0
  -- Full erase: write zeros across the entire tape
  local full = args[2] == "full"

  drive.stop()
  rewind(drive)

  if full then
    o("Full erase: wiping " .. fmtSize(drive.getSize()) .. " ...", 0x00AAFF)
    local zeros = string.rep("\0", BLOCK)
    local size = drive.getSize()
    local written = 0
    while written < size do
      local chunk = math.min(BLOCK, size - written)
      if chunk < BLOCK then
        drive.write(string.rep("\0", chunk))
      else
        drive.write(zeros)
      end
      written = written + chunk
      if written % (BLOCK * 16) == 0 then
        computer.pullSignal(0)
      end
    end
    rewind(drive)
    o("Tape erased (" .. fmtSize(size) .. " zeroed)", 0x00FF00)
  else
    -- Quick erase: just mark empty archive
    tapeWrite(drive, EOA)
    rewind(drive)
    o("Tape quick-erased (archive header cleared)", 0x00FF00)
    o("Use 'tape erase full' to zero all bytes", 0xAAAAAA)
  end
end

--- tape dump <offset> <length> — hex dump of tape contents
local function cmdDump(args, o)
  local offset = tonumber(args[2]) or 0
  local length = tonumber(args[3]) or 128

  if length > 1024 then
    length = 1024
    o("(clamped to 1024 bytes)", 0xAAAAAA)
  end

  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  drive.stop()
  seekTo(drive, offset)

  local data = tapeRead(drive, length)
  if not data then
    o("Could not read tape at offset " .. offset, 0xFF0000)
    rewind(drive)
    return
  end

  o(string.format(" Tape dump: offset %d, %d bytes", offset, #data), 0xFFFF00)
  o("", 0xFFFFFF)

  -- Format as hex dump: OFFSET  HEX  ASCII
  for row = 0, #data - 1, 16 do
    local hex = {}
    local ascii = {}
    for col = 0, 15 do
      local idx = row + col + 1
      if idx <= #data then
        local b = data:byte(idx)
        hex[#hex + 1] = string.format("%02X", b)
        ascii[#ascii + 1] = (b >= 32 and b < 127) and string.char(b) or "."
      else
        hex[#hex + 1] = "  "
        ascii[#ascii + 1] = " "
      end
    end
    local addr = offset + row
    o(string.format(" %06X  %s  %s",
      addr,
      table.concat(hex, " "),
      table.concat(ascii)),
      0xFFFFFF)
  end

  rewind(drive)
end

--- tape seek <position> — seek the tape head to a position
local function cmdSeek(args, o)
  local pos = tonumber(args[2])
  if not pos then
    o("Usage: tape seek <position>", 0xAAAAAA)
    o("  Moves the tape head to the given byte position.", 0xAAAAAA)
    return
  end

  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  seekTo(drive, pos)
  o("Tape head at byte " .. pos, 0x00FF00)
end

--- tape raw read <offset> <length> <file> — read raw bytes to file
local function cmdRawRead(args, o)
  -- args: raw read <offset> <length> <file>
  local offset = tonumber(args[3])
  local length = tonumber(args[4])
  local file   = args[5]

  if not offset or not length or not file then
    o("Usage: tape raw read <offset> <length> <file>", 0xAAAAAA)
    o("  Read raw bytes from tape and save to a file.", 0xAAAAAA)
    return
  end

  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  drive.stop()
  seekTo(drive, offset)

  o("Reading " .. fmtSize(length) .. " from tape at " .. offset .. " ...", 0x00AAFF)

  -- Read in chunks and write directly to file
  local fh, ferr = fs.open(file, "w")
  if not fh then
    o("Cannot open file: " .. tostring(ferr), 0xFF0000)
    rewind(drive)
    return
  end

  local remaining = length
  local total = 0
  while remaining > 0 do
    local chunk = drive.read(math.min(remaining, BLOCK))
    if not chunk or #chunk == 0 then
      o("Tape ended after " .. fmtSize(total), 0xFF6600)
      break
    end
    fh:write(chunk)
    total = total + #chunk
    remaining = remaining - #chunk
    if total % (BLOCK * 8) == 0 then computer.pullSignal(0) end
  end
  fh:close()
  rewind(drive)

  o("Saved " .. fmtSize(total) .. " to " .. file, 0x00FF00)
end

--- tape raw write <offset> <file> — write raw bytes from file to tape
local function cmdRawWrite(args, o)
  -- args: raw write <offset> <file>
  local offset = tonumber(args[3])
  local file   = args[4]

  if not offset or not file then
    o("Usage: tape raw write <offset> <file>", 0xAAAAAA)
    o("  Write raw file contents to tape at the given offset.", 0xAAAAAA)
    return
  end

  local drive, err = findDrive(nil)
  if not drive then o(err, 0xFF0000); return end
  if not drive.isReady() then
    o("No tape inserted.", 0xFF6600); return
  end

  if not fs.exists(file) then
    o("File not found: " .. file, 0xFF0000); return
  end

  local data = fs.readFile(file)
  if not data then
    o("Cannot read file: " .. file, 0xFF0000); return
  end

  drive.stop()
  seekTo(drive, offset)

  o("Writing " .. fmtSize(#data) .. " to tape at " .. offset .. " ...", 0x00AAFF)
  tapeWrite(drive, data)
  rewind(drive)

  o("Wrote " .. fmtSize(#data) .. " from " .. file, 0x00FF00)
end

-- ── Main command dispatcher ──────────────────────────────

local function tapeCmd(args, o)
  local sub = args[1]

  if not sub or sub == "help" then
    o("=== Tape Storage Module ===", 0xFFFF00)
    o("", 0xFFFFFF)
    o(" Discovery & Info", 0x00FF00)
    o("  tape detect           List tape drives and status", 0xFFFFFF)
    o("  tape info             Tape details (label, size, format)", 0xFFFFFF)
    o("  tape label [name]     Get or set tape label", 0xFFFFFF)
    o("", 0xFFFFFF)
    o(" Archive Operations", 0x00FF00)
    o("  tape store <path>     Archive file/directory to tape", 0xFFFFFF)
    o("  tape restore [path]   Restore archive to path (default /home)", 0xFFFFFF)
    o("  tape list             List entries in tape archive", 0xFFFFFF)
    o("", 0xFFFFFF)
    o(" Low-Level Tools", 0x00FF00)
    o("  tape dump [off] [len] Hex dump (default: 0, 128)", 0xFFFFFF)
    o("  tape seek <pos>       Move tape head to byte position", 0xFFFFFF)
    o("  tape erase [full]     Quick-erase or full zero-wipe", 0xFFFFFF)
    o("", 0xFFFFFF)
    o(" Raw I/O", 0x00FF00)
    o("  tape raw read <off> <len> <file>", 0xFFFFFF)
    o("     Read raw bytes from tape into a file", 0xAAAAAA)
    o("  tape raw write <off> <file>", 0xFFFFFF)
    o("     Write raw file bytes to tape at offset", 0xAAAAAA)
    return
  end

  if     sub == "detect"  then cmdDetect(args, o)
  elseif sub == "info"    then cmdInfo(args, o)
  elseif sub == "label"   then cmdLabel(args, o)
  elseif sub == "store"   then cmdStore(args, o)
  elseif sub == "restore" then cmdRestore(args, o)
  elseif sub == "list"    then cmdList(args, o)
  elseif sub == "erase"   then cmdErase(args, o)
  elseif sub == "dump"    then cmdDump(args, o)
  elseif sub == "seek"    then cmdSeek(args, o)
  elseif sub == "raw"     then
    local rawSub = args[2]
    if rawSub == "read"  then cmdRawRead(args, o)
    elseif rawSub == "write" then cmdRawWrite(args, o)
    else
      o("Usage: tape raw read|write ...", 0xAAAAAA)
      o("  tape raw read <offset> <length> <file>", 0xAAAAAA)
      o("  tape raw write <offset> <file>", 0xAAAAAA)
    end
  else
    o("Unknown subcommand: " .. tostring(sub), 0xFF6600)
    o("Type 'tape help' for usage.", 0xAAAAAA)
  end
end

-- ── Module return ────────────────────────────────────────
-- Module system expects: { commands = { name = fn } }

mod.commands = {
  tape = tapeCmd,
}

return mod
