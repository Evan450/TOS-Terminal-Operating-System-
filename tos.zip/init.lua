-- ╔══════════════════════════════════════╗
-- ║  TOS init.lua - System Bootstrap     ║
-- ║  Terminal Operating System v1.2.5    ║
-- ╚══════════════════════════════════════╝
-- Works with TOS BIOS (receives bootFS as arg)
-- AND with standard Lua BIOS (finds bootFS itself)

-- bootFS may be passed by TOS BIOS, or nil if standard BIOS
local bootFS = ...

-- In OC, component and computer are machine globals.
-- Do NOT use require() here - it doesn't exist yet.
local component = component
local computer = computer

-- ============================================================
-- Stage 0: Find boot filesystem
-- ============================================================
-- If TOS BIOS passed it, great. Otherwise find it ourselves.
if not bootFS then
  -- Try computer.getBootAddress (added by standard Lua BIOS or TOS BIOS)
  local getBA = computer.getBootAddress
  if getBA then
    local addr = getBA()
    if addr and addr ~= "" then
      local ok, px = pcall(component.proxy, addr)
      if ok and px then bootFS = px end
    end
  end
end
-- Last resort: scan all filesystems for one with /tos/kernel/init.lua
if not bootFS then
  for addr in component.list("filesystem") do
    local ok, px = pcall(component.proxy, addr)
    if ok and px and px.exists("/tos/kernel/init.lua") then
      bootFS = px
      break
    end
  end
end
-- Absolute last resort: any filesystem with /init.lua
if not bootFS then
  for addr in component.list("filesystem") do
    local ok, px = pcall(component.proxy, addr)
    if ok and px and px.exists("/init.lua") then
      bootFS = px
      break
    end
  end
end

if not bootFS then
  error("FATAL: Cannot find boot filesystem!")
end

-- ============================================================
-- Floppy detection: If booting from a small/removable disk
-- while a larger drive exists, offer to install there instead.
-- ============================================================
do
  local bootTotal = bootFS.spaceTotal()
  local FLOPPY_THRESHOLD = 524288  -- 512KB (floppies are ~512KB)
  if bootTotal and bootTotal <= FLOPPY_THRESHOLD then
    -- Look for a larger disk to install onto
    local largerDisk = nil
    local largerTotal = 0
    for addr in component.list("filesystem") do
      if addr ~= bootFS.address then
        local ok2, px = pcall(component.proxy, addr)
        if ok2 and px then
          local t2 = px.spaceTotal()
          if t2 and t2 > bootTotal and t2 > largerTotal then
            largerDisk = px
            largerTotal = t2
          end
        end
      end
    end
    if largerDisk then
      -- We're booting from a floppy but a hard drive exists.
      -- Show a choice to the user.
      local g2
      for addr in component.list("gpu") do g2 = component.proxy(addr) break end
      local s2
      for addr in component.list("screen") do s2 = addr break end
      if g2 and s2 then
        pcall(g2.bind, s2)
        g2.setBackground(0x000000)
        g2.setForeground(0xFFFFFF)
        local sw, sh = g2.getResolution()
        g2.fill(1, 1, sw, sh, " ")
        local function gp(y, text, fg)
          g2.setForeground(fg or 0xFFFFFF)
          g2.set(2, y, tostring(text))
        end
        local bKB = math.floor(bootTotal / 1024)
        local dKB = math.floor(largerTotal / 1024)
        gp(2, "TOS is running from a floppy disk (" .. bKB .. "KB)", 0xFFFF00)
        gp(3, "A larger drive was detected (" .. dKB .. "KB)", 0xFFFF00)
        gp(5, "1. Install TOS to the hard drive (recommended)", 0x00FF00)
        gp(6, "2. Continue booting from floppy (limited space)", 0xAAAAAA)
        gp(8, "Press 1 or 2:", 0xFFFFFF)
        -- Wait for keypress
        while true do
          local sig, _, char = computer.pullSignal(60)
          if sig == "key_down" then
            if char == 49 then  -- "1"
              -- Run install.lua if available on the floppy
              if bootFS.exists("/install.lua") then
                -- Load and execute install.lua, passing the floppy's bootFS
                g2.fill(1, 1, sw, sh, " ")
                gp(2, "Starting installer...", 0x00AAFF)
                -- We need to bootstrap just enough to run install.lua
                -- Switch boot target to the larger disk and run installer
                local instParts = {}
                local ih = bootFS.open("/install.lua", "r")
                if ih then
                  while true do
                    local chunk = bootFS.read(ih, 4096)
                    if not chunk then break end
                    instParts[#instParts + 1] = chunk
                  end
                  bootFS.close(ih)
                end
                local instSrc = table.concat(instParts)
                -- The install.lua needs OpenOS require, but we're pre-require.
                -- Instead, set bootFS to the larger disk and reboot into it
                -- after copying init.lua + core files.
                g2.fill(1, 1, sw, sh, " ")
                gp(2, "Copying TOS to hard drive...", 0x00AAFF)
                local y2 = 4
                local copied2 = 0
                -- Recursive copy from floppy to target disk
                local function copyDir(srcFS, dstFS, dir)
                  local iter = srcFS.list(dir)
                  if not iter then return end
                  for _, name in ipairs(iter) do
                    local srcPath = dir .. name
                    if srcFS.isDirectory(srcPath) then
                      dstFS.makeDirectory(srcPath)
                      copyDir(srcFS, dstFS, srcPath)
                    else
                      local fh = srcFS.open(srcPath, "r")
                      if fh then
                        local parts = {}
                        while true do
                          local chunk = srcFS.read(fh, 4096)
                          if not chunk then break end
                          parts[#parts + 1] = chunk
                        end
                        srcFS.close(fh)
                        local content = table.concat(parts)
                        local wh = dstFS.open(srcPath, "w")
                        if wh then
                          dstFS.write(wh, content)
                          dstFS.close(wh)
                          copied2 = copied2 + 1
                        end
                      end
                    end
                  end
                end
                -- Create core directories on target
                local coreDirs = {
                  "/tos/", "/tos/kernel/", "/tos/kernel/net/", "/tos/shell/",
                  "/tos/compat/", "/tos/peripheral/",
                  "/etc/", "/etc/rc.d/", "/home/", "/root/", "/public/",
                  "/usr/", "/usr/bin/", "/usr/lib/", "/usr/modules/",
                  "/var/", "/var/log/", "/var/run/", "/tmp/",
                }
                for _, d in ipairs(coreDirs) do
                  largerDisk.makeDirectory(d)
                end
                copyDir(bootFS, largerDisk, "/")
                gp(y2, "Copied " .. copied2 .. " files", 0x00FF00)
                y2 = y2 + 1
                -- Flash BIOS to point to the new drive
                gp(y2, "Setting boot drive...", 0x00AAFF)
                computer.setBootAddress(largerDisk.address)
                y2 = y2 + 1
                gp(y2, "", 0xFFFFFF)
                y2 = y2 + 1
                gp(y2, "TOS installed to hard drive!", 0x00FF00)
                y2 = y2 + 1
                gp(y2, "Rebooting in 3 seconds...", 0xAAAAAA)
                computer.pullSignal(3)
                computer.shutdown(true)
              else
                gp(10, "install.lua not found on floppy!", 0xFF0000)
                gp(11, "Booting from floppy instead...", 0xAAAAAA)
                computer.pullSignal(2)
              end
              break
            elseif char == 50 then  -- "2"
              break  -- Continue booting from floppy
            end
          elseif not sig then
            break  -- Timeout: continue booting from floppy
          end
        end
      end
    end
  end
end

-- ============================================================
-- Global TOS state
-- ============================================================
_G._TOS = {
  version    = "1.2.5",
  codename   = "Atlas",
  bootFS     = bootFS,
  bootTime   = computer.uptime(),
  startMem   = computer.freeMemory(),
  totalMem   = computer.totalMemory(),
}

-- ============================================================
-- Stage 1: Build require() system
-- ============================================================
local loaded = {}
local loading = {}

local searchPaths = {
  "/tos/?.lua",
  "/tos/?/init.lua",
  "/lib/?.lua",
  "/usr/lib/?.lua",
  "/usr/bin/?.lua",
}

-- Package compat: loaded table accessible as package.loaded
-- (needed by compat/init.lua to register OpenOS shims)
_G.package = { loaded = nil }  -- Set after loaded table creation

local function readFile(path)
  if not bootFS.exists(path) then return nil end
  local h = bootFS.open(path, "r")
  if not h then return nil end

  local parts = {}
  while true do
    local chunk = bootFS.read(h, 4096)
    if not chunk then break end
    parts[#parts + 1] = chunk
  end
  bootFS.close(h)
  return table.concat(parts)
end

local function tosRequire(name)
  if loaded[name] then return loaded[name] end
  if loading[name] then
    error("Circular dependency: " .. name, 2)
  end
  loading[name] = true

  local modName = name:gsub("%.", "/")
  local tried = {}
  for _, pattern in ipairs(searchPaths) do
    local path = pattern:gsub("%?", modName)
    local source = readFile(path)
    if source then
      local fn, err = load(source, "=" .. path)
      if not fn then
        loading[name] = nil
        error("Syntax error in '" .. name .. "' (" .. path .. "): " .. tostring(err), 2)
      end
      local ok, result = pcall(fn, name)
      if not ok then
        loading[name] = nil
        error("Runtime error in '" .. name .. "': " .. tostring(result), 2)
      end
      if result == nil then result = true end
      loaded[name] = result
      loading[name] = nil
      return result
    end
    tried[#tried + 1] = path
  end

  loading[name] = nil
  error("Module not found: " .. name .. "\nSearched:\n  " .. table.concat(tried, "\n  "), 2)
end

_G.require = tosRequire

-- Pre-register machine globals as modules so require("computer") etc. works
loaded["component"] = component
loaded["computer"] = computer
if unicode then loaded["unicode"] = unicode end

-- Expose loaded table as package.loaded for OpenOS compat
_G.package.loaded = loaded

-- ============================================================
-- Stage 2: GPU + Early Display
-- ============================================================
local gpuAddr
for addr in component.list("gpu") do gpuAddr = addr break end
local screenAddr
for addr in component.list("screen") do screenAddr = addr break end
local gpu

if gpuAddr and screenAddr then
  gpu = component.proxy(gpuAddr)
  -- Skip bind() if TOS BIOS already did it: gpu.bind() resets the GPU buffer
  -- (clears screen) in OC even when re-binding the same screen.
  if not _G._BIOS_CY then
    gpu.bind(screenAddr)
  end
  _G._TOS.gpu = gpu
end

local screenW, screenH = 50, 16
if gpu then
  screenW, screenH = gpu.getResolution()
end

-- Detect GPU color depth for tier-safe rendering
local gpuDepth = _G._BIOS_DEPTH or 1
if gpu then
  local ok, d = pcall(gpu.getDepth)
  if ok and d then gpuDepth = d end
end
local isMonochrome = gpuDepth <= 1

--- Map a color to a tier-safe value (T1 → white only)
local function tc(color)
  if isMonochrome then return 0xFFFFFF end
  return color
end

local cursorY = 1

local function earlyPrint(text, color)
  if not gpu then return end
  if color then gpu.setForeground(tc(color)) end
  if cursorY > screenH then
    gpu.copy(1, 2, screenW, screenH - 1, 0, -1)
    cursorY = screenH
  end
  -- Clear full line then write text (prevents remnant chars from longer lines)
  gpu.fill(1, cursorY, screenW, 1, " ")
  gpu.set(1, cursorY, tostring(text))
  cursorY = cursorY + 1
end

local function earlyClear()
  if not gpu then return end
  gpu.setBackground(0x000000)
  gpu.setForeground(tc(0x00FF00))
  gpu.fill(1, 1, screenW, screenH, " ")
  cursorY = 1
end

-- ============================================================
-- Stage 3: Boot splash
-- ============================================================
if _G._BIOS_CY then
  cursorY = _G._BIOS_CY
  if gpu then
    gpu.setBackground(0x000000)
    gpu.setForeground(tc(0x00FF00))
  end
else
  earlyClear()
end

local totalKB = math.floor(_G._TOS.totalMem / 1024)
local freeKB  = math.floor(computer.freeMemory() / 1024)

local bar = string.rep(isMonochrome and "=" or "═", math.min(38, screenW))
earlyPrint(bar, tc(0x00AAFF))
earlyPrint("  TOS v" .. _G._TOS.version .. " [" .. _G._TOS.codename .. "]", tc(0x00AAFF))
earlyPrint(bar, tc(0x00AAFF))
earlyPrint("  Memory: " .. freeKB .. "K free / " .. totalKB .. "K total", tc(0xAAAAAA))
if totalKB < 128 then
  earlyPrint("  WARNING: Low memory - features limited!", tc(0xFF0000))
elseif totalKB < 256 then
  earlyPrint("  NOTE: Limited memory - some features may be skipped", tc(0xFFFF00))
end

-- ============================================================
-- Stage 4: Verify & load kernel
-- ============================================================
-- Load system manifest for file verification (single source of truth).
-- Falls back to a minimal hardcoded list if the manifest is missing.
local criticalFiles = {}
do
  local manifestHandle = bootFS.open("/tos/system_manifest.lua", "r")
  if manifestHandle then
    local parts = {}
    repeat
      local chunk = bootFS.read(manifestHandle, 4096)
      if chunk then parts[#parts + 1] = chunk end
    until not chunk
    bootFS.close(manifestHandle)
    local manifestFn = load(table.concat(parts), "=system_manifest")
    if manifestFn then
      local allFiles = manifestFn()
      if type(allFiles) == "table" then
        for _, entry in ipairs(allFiles) do
          -- Boot only checks critical files
          if entry.critical then
            criticalFiles[#criticalFiles + 1] = entry.path
          end
        end
      end
    end
  end
  -- Fallback: if manifest missing or failed, check absolute minimum
  if #criticalFiles == 0 then
    criticalFiles = {
      "/tos/kernel/init.lua",
      "/tos/kernel/log.lua",
      "/tos/kernel/hal.lua",
      "/tos/kernel/event.lua",
      "/tos/kernel/process.lua",
      "/tos/kernel/fs.lua",
      "/tos/kernel/serialize.lua",
      "/tos/kernel/display.lua",
      "/tos/shell/init.lua",
    }
  end
end
local missingFiles = {}
for _, path in ipairs(criticalFiles) do
  if not bootFS.exists(path) then
    missingFiles[#missingFiles + 1] = path
  end
end
if #missingFiles > 0 then
  earlyPrint("MISSING " .. #missingFiles .. " FILES:", tc(0xFF0000))
  for _, path in ipairs(missingFiles) do
    earlyPrint("  " .. path, tc(0xFF6600))
  end
  earlyPrint("Press any key to reboot...", tc(0xAAAAAA))
  computer.beep(400, 0.5)
  computer.pullSignal(math.huge)
  computer.shutdown(true)
end

earlyPrint("  Verifying: " .. (#criticalFiles - #missingFiles) .. "/" .. #criticalFiles .. " system files OK", tc(0x00FF00))
earlyPrint("  Loading kernel...", tc(0x00FF00))

local ok, err = xpcall(function()
  local kernel = require("kernel")
  kernel.boot({
    gpu        = gpu,
    gpuDepth   = gpuDepth,
    screenW    = screenW,
    screenH    = screenH,
    earlyPrint = earlyPrint,
    bootFS     = bootFS,
  })
end, function(e)
  return tostring(e) .. "\n" .. debug.traceback("", 2)
end)

if not ok then
  earlyClear()
  earlyPrint("", tc(0xFF0000))
  earlyPrint("======= KERNEL PANIC =======", tc(0xFF0000))
  earlyPrint("", tc(0xFF6600))
  -- Split error into visible lines
  local errStr = tostring(err) or "Unknown error"
  for line in errStr:gmatch("[^\n]+") do
    if #line > screenW then
      line = line:sub(1, screenW - 3) .. "..."
    end
    earlyPrint(line, tc(0xFF6600))
  end
  earlyPrint("", tc(0xAAAAAA))
  earlyPrint("Free RAM: " .. math.floor(computer.freeMemory() / 1024) .. "KB", tc(0xAAAAAA))
  earlyPrint("", tc(0xFFFF00))
  earlyPrint("Press any key to reboot...", tc(0xFFFF00))
  -- Kernel panic beep code: three low beeps
  computer.beep(400, 0.15)
  computer.pullSignal(0.05)
  computer.beep(400, 0.15)
  computer.pullSignal(0.05)
  computer.beep(400, 0.15)
  computer.pullSignal(math.huge)
  computer.shutdown(true)
end
