-- ╔══════════════════════════════════════╗
-- ║  TOS OpenOS Compatibility Layer     ║
-- ║  Registers shims for OpenOS APIs   ║
-- ╚══════════════════════════════════════╝
-- Allows OpenOS programs (including OPPM) to run on TOS by providing
-- compatible implementations of standard OpenOS libraries.
-- Loaded during kernel boot if sufficient RAM is available.

local compat = {}

--- Register all compatibility modules in the require() cache.
-- After this, require("term"), require("filesystem"), etc. work
-- as OpenOS programs expect.
-- @param opts table: { procSleep = function } (optional, injected post-boot)
function compat.init(opts)
  opts = opts or {}
  -- The TOS require system uses a `loaded` table.
  -- We need to pre-register our shims so they're found before
  -- the search path lookup (which wouldn't find "term" etc.)

  -- Map of OpenOS module name -> TOS compat module path
  local shims = {
    ["sides"]         = "compat.sides",
    ["colors"]        = "compat.colors",
    ["keyboard"]      = "compat.keyboard",
    ["text"]          = "compat.text",
    ["serialization"] = "compat.serialization",
    ["buffer"]        = "compat.buffer",
    ["term"]          = "compat.term",
    ["filesystem"]    = "compat.filesystem",
    ["event"]         = "compat.event",
    ["shell"]         = "compat.shell_api",
    ["io"]            = "compat.io",
  }

  local loaded = 0
  local failed = 0

  for openosName, tosPath in pairs(shims) do
    local ok, mod = pcall(require, tosPath)
    if ok then
      -- Register under the OpenOS name so require("term") finds it
      package.loaded[openosName] = mod
      loaded = loaded + 1
    else
      -- Non-fatal: some shims may fail on low RAM
      failed = failed + 1
    end
  end

  -- Also register `io` as a global (Lua standard)
  if package.loaded["io"] then
    _G.io = package.loaded["io"]
  end

  -- ── component.* OpenOS extensions ──────────────────────
  -- OpenOS wraps the raw component library with helper functions
  -- that many community programs depend on (isAvailable, get, field access).
  do
    local rawComp = require("component")

    -- component.isAvailable(type): true if at least one component exists
    if not rawComp.isAvailable then
      rawComp.isAvailable = function(ctype)
        local addr = rawComp.list(ctype)()
        return addr ~= nil
      end
    end

    -- component.get(partialAddress, type): resolve partial address to full
    if not rawComp.get then
      rawComp.get = function(address, ctype)
        if type(address) ~= "string" then return nil, "invalid address" end
        for addr in rawComp.list(ctype) do
          if addr:sub(1, #address) == address then
            return addr
          end
        end
        return nil, "no such component"
      end
    end

    -- component.getPrimary(type): get primary proxy (alias for field access)
    if not rawComp.getPrimary then
      rawComp.getPrimary = function(ctype)
        local addr = rawComp.list(ctype)()
        if addr then return rawComp.proxy(addr) end
        return nil, "no primary " .. tostring(ctype) .. " component"
      end
    end

    -- component.<type> field access: e.g. component.tape_drive returns proxy
    -- OpenOS does this via metatable __index on the component table.
    local existingMT = getmetatable(rawComp)
    local existingIndex = existingMT and existingMT.__index
    local proxyCache = setmetatable({}, { __mode = "v" })
    setmetatable(rawComp, {
      __index = function(self, key)
        -- Check existing metatable first
        if existingIndex then
          local val
          if type(existingIndex) == "function" then
            val = existingIndex(self, key)
          elseif type(existingIndex) == "table" then
            val = existingIndex[key]
          end
          if val ~= nil then return val end
        end
        -- Try to find a component of this type and return its proxy
        -- Use a weak cache so proxies for removed components get GC'd
        if proxyCache[key] then
          -- Verify the cached proxy is still valid
          local ok = pcall(rawComp.type, proxyCache[key].address)
          if ok then return proxyCache[key] end
          proxyCache[key] = nil
        end
        local addr = rawComp.list(key)()
        if addr then
          local proxy = rawComp.proxy(addr)
          proxyCache[key] = proxy
          return proxy
        end
        return nil
      end,
    })
  end

  -- ── print() override ───────────────────────────────────
  -- Route print() through the compat io module so output goes through
  -- term.write() instead of directly to the GPU buffer.
  if package.loaded["io"] then
    local iomod = package.loaded["io"]
    _G.print = function(...)
      local args = table.pack(...)
      for i = 1, args.n do
        if i > 1 then iomod.write("\t") end
        iomod.write(tostring(args[i]))
      end
      iomod.write("\n")
    end
  end

  -- ── os.* extensions (OpenOS compatibility) ──────────────
  -- OpenOS extends Lua's os table with sleep, getenv, setenv, etc.
  -- Many community programs depend on these.
  if not _G.os then _G.os = {} end

  -- os.sleep: yield for N seconds without blocking other processes.
  -- If proc.sleep is available (injected from kernel after boot), uses
  -- coroutine.yield so the TOS scheduler can run other processes.
  -- Falls back to chunked pullSignal for pre-scheduler contexts.
  do
    local computer2 = require("computer")
    local _procSleep = opts.procSleep  -- may be nil during early boot

    _G.os.sleep = function(seconds)
      seconds = tonumber(seconds) or 0
      if seconds <= 0 then
        -- Yield once to let other work happen
        if _procSleep then
          _procSleep(0)
        else
          computer2.pullSignal(0)
        end
        return
      end
      if _procSleep then
        _procSleep(seconds)
      else
        -- Fallback: chunked pullSignal (blocks scheduler but not forever)
        local deadline = computer2.uptime() + seconds
        while computer2.uptime() < deadline do
          local remaining = deadline - computer2.uptime()
          computer2.pullSignal(math.min(remaining, 0.5))
        end
      end
    end

    -- Allow late injection of proc.sleep (called from kernel after boot)
    function compat.setProcSleep(fn)
      _procSleep = fn
    end
  end

  -- os.getenv / os.setenv: environment variables
  if not _G.os.getenv then
    local envVars = {
      HOME = "/home",
      SHELL = "/tos/shell/init.lua",
      TERM = "tos",
      PATH = "/usr/bin:/bin",
    }
    -- Try to load from kernel.env if available
    local ok3, envMod = pcall(require, "kernel.env")
    _G.os.getenv = function(name)
      if ok3 and envMod.read then
        local val = envMod.read(nil, name)
        if val then return val end
      end
      return envVars[name]
    end
    _G.os.setenv = function(name, value)
      if ok3 and envMod.write then
        envMod.write(nil, name, value)
      else
        envVars[name] = value
      end
    end
  end

  -- os.tmpname: return a temporary file path
  if not _G.os.tmpname then
    local tmpCounter = math.floor(require("computer").uptime() * 100) % 10000
    _G.os.tmpname = function()
      tmpCounter = tmpCounter + 1
      return "/tmp/tos_tmp_" .. tmpCounter
    end
  end

  return loaded, failed
end

--- Check if a specific OpenOS module is available.
function compat.has(name)
  return package.loaded[name] ~= nil
end

--- Get the list of registered shims.
function compat.list()
  local result = {}
  local names = {"sides","colors","keyboard","text","serialization",
                  "buffer","term","filesystem","event","shell","io"}
  for _, name in ipairs(names) do
    result[#result + 1] = {
      name = name,
      loaded = package.loaded[name] ~= nil,
    }
  end
  return result
end

return compat
