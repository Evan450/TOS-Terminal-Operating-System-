-- TOS OpenOS Compatibility - event API
-- Wraps TOS kernel.event to provide the OpenOS event interface.
-- OpenOS programs use require("event") for event handling.

local kEvent = require("kernel.event")
local computer = require("computer")

local event = {}

-- Track callback -> {signal, id} for event.ignore() support.
-- Uses the callback function as key (OpenOS identifies listeners by reference).
local callbackMap = {}
setmetatable(callbackMap, { __mode = "k" })  -- Weak keys: allow GC of callbacks

--- Pull a signal with optional timeout and filter.
-- OpenOS signature: event.pull([timeout: number], [name: string], ...) -> ...
-- If first arg is a number, it's timeout. If first arg is a string, it's filter name.
function event.pull(...)
  local args = table.pack(...)
  local timeout = math.huge
  local filterName = nil
  local argStart = 1

  if args.n >= 1 and type(args[1]) == "number" then
    timeout = args[1]
    argStart = 2
  end
  if args.n >= argStart and type(args[argStart]) == "string" then
    filterName = args[argStart]
  end

  if filterName then
    return kEvent.pullFiltered(function(sig)
      return sig == filterName
    end, timeout)
  else
    return kEvent.pull(timeout)
  end
end

--- Listen for a signal (persistent handler).
function event.listen(name, callback)
  -- Check if already listening (OpenOS behavior: no-op on duplicate)
  if callbackMap[callback] then return false end
  local id = kEvent.on(name, callback, "compat:event")
  callbackMap[callback] = { signal = name, id = id }
  return true
end

--- Remove a listener (by callback reference, matching OpenOS behavior).
function event.ignore(name, callback)
  local entry = callbackMap[callback]
  if not entry then return false end
  local removed = kEvent.off(entry.signal, entry.id)
  callbackMap[callback] = nil
  return removed or false
end

--- Register a one-shot listener.
function event.listenOnce(name, callback)
  kEvent.once(name, callback, "compat:event")
  return true
end

--- Register a timer (one-shot delayed callback).
-- @return number: Timer ID
function event.timer(interval, callback, times)
  times = times or 1
  if times == math.huge then
    -- Repeating
    return kEvent.interval(interval, callback, "compat:timer")
  else
    -- One-shot (or limited repeats)
    local count = 0
    local id
    id = kEvent.interval(interval, function()
      count = count + 1
      callback()
      if count >= times then
        kEvent.cancelTimer(id)
      end
    end, "compat:timer")
    return id
  end
end

--- Cancel a timer.
function event.cancel(id)
  return kEvent.cancelTimer(id)
end

--- Push an event into the queue.
function event.push(name, ...)
  kEvent.push(name, ...)
end

--- Get computer uptime
function event.uptime()
  return computer.uptime()
end

return event
