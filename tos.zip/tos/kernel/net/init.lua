-- ╔══════════════════════════════════════╗
-- ║  TOS Network - Main Network Layer    ║
-- ║  Zero-trust modem/tunnel comms       ║
-- ╚══════════════════════════════════════╝
-- SECURITY POLICY: Every incoming packet is checked against
-- the trust manager BEFORE any processing occurs. Untrusted
-- machines can only ping. Everything else is denied silently.

local component = require("component")
local computer = require("computer")

local net = {}

-- Sub-modules
local protocol = nil
local trustMgr = nil
local crypto   = nil

-- Hardware
local modem    = nil   -- Primary modem (back-compat)
local tunnel   = nil
local myAddr   = nil
-- Multi-NIC: all available modems. modem == modems[1].proxy for compat.
local modems   = {}    -- { { addr, proxy, wireless }, ... }

-- Config
local listenPort    = 42
local broadcastPort = 43
local encryptComms  = true
local hostname      = "tos"

-- State
local running   = false
local listeners = {}  -- msgType -> { callback, ... }
-- Message log: true circular ring buffer (O(1) inserts, no table.remove shifts)
local messageLog = {}
local LOG_SIZE   = 32
local logHead    = 1   -- Next write slot (1-indexed)
local logCount   = 0   -- How many valid entries exist (≤ LOG_SIZE)

-- Module refs
local log    = nil
local config = nil
local event  = nil

-- Forward declarations (prevent global namespace pollution)
local logMessage
local dispatchToListeners

-- ============================================================
-- Initialization
-- ============================================================

function net.init(modules)
  log    = modules.log
  config = modules.config
  event  = modules.event

  -- Load sub-modules
  protocol = require("kernel.net.protocol")
  trustMgr = require("kernel.net.trust")
  crypto   = require("kernel.crypto")

  trustMgr.init({
    fs     = modules.fs,
    crypto = crypto,
    log    = log,
    config = config,
  })

  -- Load config
  if config then
    listenPort    = config.get("listenPort") or 42
    broadcastPort = config.get("broadcastPort") or 43
    encryptComms  = config.get("encryptComms") ~= false
    hostname      = config.get("hostname") or "tos"
  end

  -- Detect hardware: enumerate ALL modems (multi-NIC for server racks)
  modems = {}
  for addr in component.list("modem") do
    local ok, proxy = pcall(component.proxy, addr)
    if ok and proxy then
      pcall(proxy.open, listenPort)
      pcall(proxy.open, broadcastPort)
      local wireless = false
      pcall(function() wireless = proxy.isWireless() end)
      modems[#modems + 1] = { addr = addr, proxy = proxy, wireless = wireless }
      if log then
        log.info("net", string.format("Modem %d: %s [%s]",
          #modems, wireless and "wireless" or "wired", addr:sub(1, 8) .. "..."))
      end
    end
  end
  -- Primary modem = first one found (back-compat)
  if #modems > 0 then
    modem  = modems[1].proxy
    myAddr = modems[1].addr
    if log and #modems > 1 then
      log.info("net", #modems .. " NICs active (multi-modem)")
    end
    if log then
      log.info("net", "Listening on ports " .. listenPort .. ", " .. broadcastPort)
    end
  end

  -- Detect tunnel (linked card)
  for addr in component.list("tunnel") do
    local ok, proxy = pcall(component.proxy, addr)
    if ok and proxy then
      tunnel = proxy
      if log then log.info("net", "Linked card detected") end
    end
    break
  end

  if not modem and not tunnel then
    if log then log.warn("net", "No network hardware detected") end
    return false
  end

  -- Register modem_message event handler
  if event then
    event.on("modem_message", function(_, localAddr, remoteAddr, port, dist, rawData)
      net.handleIncoming(remoteAddr, port, dist, rawData)
    end, "net")
  end

  running = true

  if log then
    log.info("net", "Network initialized (zero-trust mode)")
    log.info("net", "Encryption: " .. (encryptComms and "enabled" or "disabled"))
  end

  return true
end

function net.isAvailable()
  return modem ~= nil or tunnel ~= nil
end

function net.getAddress()
  return myAddr
end

function net.getHostname()
  return hostname
end

--- Return the list of all modems (multi-NIC support).
-- Each entry: { addr = string, wireless = bool }
function net.listModems()
  local result = {}
  for _, m in ipairs(modems) do
    result[#result + 1] = { addr = m.addr, wireless = m.wireless }
  end
  return result
end

--- Return count of available modems.
function net.modemCount()
  return #modems
end

-- ============================================================
-- Sending
-- ============================================================

--- Send a packet to a specific address
-- @param address string: Destination modem address
-- @param packet table: Protocol packet (from protocol.make*)
-- @param port number: (optional) port override
-- @return boolean
function net.send(address, packet, port)
  if not modem then return false, "No modem" end

  port = port or listenPort

  -- Stamp our address
  packet.from = myAddr

  -- Encrypt payload if talking to a trusted peer and encryption is on
  local peerLevel = trustMgr.getLevel(address)
  if encryptComms and peerLevel >= trustMgr.LEVEL.TRUSTED then
    local secret = trustMgr.getSecret(address)
    if secret and packet.payload then
      local plaintext = protocol.serialize(packet.payload)
      local encrypted, method = crypto.encrypt(plaintext, secret)
      packet.payload = encrypted
      packet.enc = method  -- "aes" or "xor"
    end
  end

  -- Serialize and send
  local data = protocol.serialize(packet)
  if #data > protocol.MAX_SIZE then
    return false, "Packet too large"
  end

  local ok, err2 = pcall(modem.send, address, port, data)
  if not ok then
    return false, "Send failed: " .. tostring(err2)
  end

  -- Log outgoing
  logMessage("out", address, packet.type)

  return true
end

--- Broadcast a packet to all machines on a port.
-- Multi-NIC: broadcasts on ALL modems so the packet reaches every
-- physical network the server is connected to.
function net.broadcast(packet, port)
  if not modem then return false, "No modem" end
  port = port or broadcastPort

  packet.from = myAddr
  local data = protocol.serialize(packet)
  local anyOk = false
  for _, m in ipairs(modems) do
    local ok2 = pcall(m.proxy.broadcast, port, data)
    anyOk = anyOk or ok2
  end
  if not anyOk then return false, "Broadcast failed on all NICs" end
  logMessage("out", "*broadcast*", packet.type)
  return true
end

--- Send via linked card (tunnel)
function net.sendTunnel(packet)
  if not tunnel then return false, "No linked card" end
  packet.from = myAddr or "tunnel"
  local data = protocol.serialize(packet)
  local ok, err = pcall(tunnel.send, data)
  if not ok then return false, "Tunnel send failed: " .. tostring(err) end
  logMessage("out", "tunnel", packet.type)
  return true
end

-- ============================================================
-- Receiving & trust enforcement
-- ============================================================

--- Handle an incoming modem_message
-- This is the SECURITY GATE. Every packet goes through trust checks.
function net.handleIncoming(remoteAddr, port, distance, rawData)
  if not running then return end

  -- Parse packet
  local packet, err = protocol.deserialize(rawData)
  if not packet then
    -- Not a valid packet - silently drop
    return
  end

  -- Validate it's a TOS packet
  local valid, verr = protocol.validate(packet)
  if not valid then return end  -- Not TOS traffic, ignore

  -- Record that we've seen this peer
  trustMgr.seen(remoteAddr)
  packet.from = remoteAddr  -- Ensure 'from' matches actual sender
  packet._distance = distance  -- Attach distance info

  -- ══════════════════════════════════════════════
  -- TRUST ENFORCEMENT - The core security gate
  -- ══════════════════════════════════════════════

  local peerLevel = trustMgr.getLevel(remoteAddr)

  -- BLOCKED: drop everything silently
  if peerLevel == trustMgr.LEVEL.BLOCKED then
    if log then log.debug("net", "Dropped (BLOCKED): " .. remoteAddr:sub(1, 8)) end
    return
  end

  -- Check if this message type is allowed at this trust level
  if not trustMgr.isAllowed(remoteAddr, packet.type) then
    -- Trust requests are special: always let them through so we can
    -- show them to the user (but don't act on them)
    if packet.type == protocol.TYPE.TRUST_REQ then
      local peerHostname = packet.payload and packet.payload.hostname or nil
      trustMgr.addPendingRequest(remoteAddr, peerHostname)
      logMessage("in", remoteAddr, "trust_req (pending)")
      -- Notify listeners about the request
      dispatchToListeners(protocol.TYPE.TRUST_REQ, packet, remoteAddr)
      return
    end

    -- Only send DENY to peers we already acknowledge (KNOWN+).
    -- Sending DENY to UNKNOWN peers would reveal that TOS is running
    -- and that the packet was received, which aids reconnaissance.
    if peerLevel >= trustMgr.LEVEL.KNOWN then
      if packet.type ~= protocol.TYPE.DENY and packet.type ~= protocol.TYPE.ERROR then
        local denyPkt = protocol.deny("Insufficient trust level")
        net.send(remoteAddr, denyPkt)
      end
    end

    if log then
      log.debug("net", string.format("Denied %s from %s (level: %s)",
        packet.type, remoteAddr:sub(1, 8),
        trustMgr.levelName(peerLevel)))
    end
    return
  end

  -- ══════════════════════════════════════════════
  -- DECRYPT if payload is encrypted
  -- ══════════════════════════════════════════════

  if packet.enc and packet.enc ~= false and peerLevel >= trustMgr.LEVEL.TRUSTED then
    local secret = trustMgr.getSecret(remoteAddr)
    if secret and type(packet.payload) == "string" then
      local decrypted = crypto.decrypt(packet.payload, secret, packet.enc)
      if decrypted then
        local parsed = protocol.deserialize(decrypted)
        if parsed then
          packet.payload = parsed
          packet.enc = false  -- Mark as decrypted
        end
      end
    end
  end

  -- Log incoming
  logMessage("in", remoteAddr, packet.type)

  -- ══════════════════════════════════════════════
  -- BUILT-IN HANDLERS (automatic responses)
  -- ══════════════════════════════════════════════

  if packet.type == protocol.TYPE.PING then
    -- Always respond to pings (UNKNOWN+ level)
    -- Response includes device type (safe minimal info — this is no
    -- different from what a port scan would reveal).
    local pong = protocol.pong()
    -- Enrich pong with device type if config is available
    if config then
      pong.payload = pong.payload or {}
      pong.payload.device   = config.deviceType()
      pong.payload.hostname = hostname
    end
    net.send(remoteAddr, pong)
    -- Record the pinger as a discovered peer
    net._recordPeer(remoteAddr, packet.payload)
    return
  end

  if packet.type == protocol.TYPE.PONG then
    -- Record the responder
    net._recordPeer(remoteAddr, packet.payload)
    -- Fall through to dispatch so scan() listener gets it
  end

  if packet.type == protocol.TYPE.HELLO and peerLevel >= trustMgr.LEVEL.KNOWN then
    -- Respond with our hostname (only to KNOWN+ peers)
    local peer = trustMgr.getPeer(remoteAddr)
    if peer and packet.payload then
      peer.hostname = packet.payload.hostname
    end
    local ack = protocol.helloAck(hostname, _G._TOS.version)
    net.send(remoteAddr, ack)
    -- Fall through to listeners too
  end

  if packet.type == protocol.TYPE.HELLO_ACK and peerLevel >= trustMgr.LEVEL.KNOWN then
    -- Store their hostname
    local peer = trustMgr.getPeer(remoteAddr)
    if peer and packet.payload then
      peer.hostname = packet.payload.hostname
    end
  end

  -- ══════════════════════════════════════════════
  -- DISPATCH to registered listeners
  -- ══════════════════════════════════════════════

  dispatchToListeners(packet.type, packet, remoteAddr)
end

-- ============================================================
-- Message dispatch
-- ============================================================

dispatchToListeners = function(msgType, packet, from)
  if listeners[msgType] then
    for _, entry in ipairs(listeners[msgType]) do
      local ok, err = pcall(entry.cb, packet, from)
      if not ok and log then
        log.warn("net", "Listener error for " .. tostring(msgType) .. ": " .. tostring(err))
      end
    end
  end
  -- Also dispatch to catch-all listeners
  if listeners["*"] then
    for _, entry in ipairs(listeners["*"]) do
      local ok, err = pcall(entry.cb, packet, from)
      if not ok and log then
        log.warn("net", "Catch-all listener error: " .. tostring(err))
      end
    end
  end
end

--- Register a listener for a specific message type
-- @return number: Listener ID for removal via net.off()
local listenerNextID = 1
function net.on(msgType, callback)
  if not listeners[msgType] then
    listeners[msgType] = {}
  end
  local id = listenerNextID
  listenerNextID = listenerNextID + 1
  listeners[msgType][#listeners[msgType] + 1] = { cb = callback, id = id }
  return id
end

--- Remove a listener by message type + ID
function net.off(msgType, id)
  if not listeners[msgType] then return false end
  for i, entry in ipairs(listeners[msgType]) do
    if entry.id == id then
      table.remove(listeners[msgType], i)
      return true
    end
  end
  return false
end

--- Register a catch-all listener
function net.onAny(callback)
  return net.on("*", callback)
end

-- ============================================================
-- Message log (ring buffer)
-- ============================================================

logMessage = function(direction, addr, msgType)
  messageLog[logHead] = {
    time = computer.uptime(),
    dir  = direction,
    addr = addr,
    type = msgType,
  }
  logHead = (logHead % LOG_SIZE) + 1
  if logCount < LOG_SIZE then logCount = logCount + 1 end
end

--- Return log entries oldest-first as a plain sequential table
function net.getMessageLog()
  if logCount == 0 then return {} end
  local result = {}
  -- When buffer is not yet full, oldest entry is at index 1.
  -- When full, oldest entry is at logHead (the slot about to be overwritten).
  local startIdx = logCount < LOG_SIZE and 1 or logHead
  for i = 0, logCount - 1 do
    result[i + 1] = messageLog[((startIdx - 1 + i) % LOG_SIZE) + 1]
  end
  return result
end

-- ============================================================
-- Discovery (find other TOS machines)
-- ============================================================

--- Broadcast a ping to discover other TOS machines
function net.discover()
  local ping = protocol.ping()
  return net.broadcast(ping, broadcastPort)
end

--- Send hello to a known peer (exchange hostnames)
function net.hello(address)
  local level = trustMgr.getLevel(address)
  if level < trustMgr.LEVEL.KNOWN then
    return false, "Peer must be KNOWN to exchange hellos"
  end
  local pkt = protocol.hello(hostname, _G._TOS.version)
  return net.send(address, pkt)
end

-- ============================================================
-- Secure messaging (TRUSTED peers only)
-- ============================================================

--- Send an encrypted message to a trusted peer
function net.sendMessage(address, text)
  local level = trustMgr.getLevel(address)
  if level < trustMgr.LEVEL.TRUSTED then
    return false, "Peer must be TRUSTED to send messages"
  end
  local pkt = protocol.message(text, encryptComms)
  return net.send(address, pkt)
end

--- Request trust from a remote machine
function net.requestTrust(address)
  local pkt = protocol.trustRequest(hostname)
  return net.send(address, pkt)
end

-- ============================================================
-- High-level API (used by shell commands)
-- ============================================================

--- Get the trust manager instance
function net.getTrust()
  return trustMgr
end

-- ============================================================
-- Peer Discovery (Phase 8)
-- ============================================================

-- Persistent discovered-peer table, populated by pong responses
-- and the optional discoveryd service. Entries:
--   { addr, lastSeen, device, hostname, trust }
local discoveredPeers = {}

--- Internal: record a peer from a pong response.
function net._recordPeer(addr, payload)
  local now = computer.uptime()
  local trust = trustMgr and trustMgr.getLevel(addr) or 0
  local hostname2 = nil
  local device2 = nil
  if type(payload) == "table" then
    hostname2 = payload.hostname
    device2   = payload.device
  end
  -- Merge with trust manager data if available
  if trustMgr then
    local peer = trustMgr.getPeer(addr)
    if peer then
      hostname2 = hostname2 or peer.hostname
    end
  end
  discoveredPeers[addr] = {
    addr      = addr,
    lastSeen  = now,
    hostname  = hostname2,
    device    = device2,
    trust     = trust,
  }
end

--- Return the current discovered-peer table as a sorted list.
function net.peers()
  local result = {}
  for _, peer in pairs(discoveredPeers) do
    result[#result + 1] = peer
  end
  table.sort(result, function(a, b) return (a.hostname or "") < (b.hostname or "") end)
  return result
end

--- Look up a specific peer by address or hostname.
function net.findPeer(query)
  -- Exact address match
  if discoveredPeers[query] then return discoveredPeers[query] end
  -- Hostname search
  for _, peer in pairs(discoveredPeers) do
    if peer.hostname and peer.hostname == query then return peer end
  end
  -- Partial address prefix
  for addr, peer in pairs(discoveredPeers) do
    if addr:sub(1, #query) == query then return peer end
  end
  return nil
end

--- Active scan: broadcast a ping, collect pong responses for `timeout`
--- seconds, return the peers found in this scan.
function net.scan(timeout)
  timeout = timeout or 3
  local results = {}
  local listenId = net.on(protocol.TYPE.PONG, function(packet, remoteAddr)
    net._recordPeer(remoteAddr, packet.payload)
    results[remoteAddr] = discoveredPeers[remoteAddr]
  end)
  net.discover()
  -- Wait for responses (cooperative — yields)
  local deadline = computer.uptime() + timeout
  while computer.uptime() < deadline do
    if coroutine.isyieldable and coroutine.isyieldable() then
      coroutine.yield()
    else
      computer.pullSignal(0.5)
    end
  end
  net.off(protocol.TYPE.PONG, listenId)
  local list = {}
  for _, p in pairs(results) do list[#list + 1] = p end
  return list
end

--- Get the protocol module
function net.getProtocol()
  return protocol
end

--- Get network status summary
function net.status()
  local stats = trustMgr.stats()
  return {
    available    = net.isAvailable(),
    address      = myAddr and (myAddr:sub(1, 8) .. "...") or "none",
    fullAddress  = myAddr,
    hostname     = hostname,
    listenPort   = listenPort,
    encrypted    = encryptComms,
    hasModem     = modem ~= nil,
    hasTunnel    = tunnel ~= nil,
    peers        = stats,
    messageCount = logCount,
  }
end

function net.shutdown()
  running = false
  if modem then
    pcall(function()
      modem.close(listenPort)
      modem.close(broadcastPort)
    end)
  end
  if log then log.info("net", "Network shut down") end
end

return net
