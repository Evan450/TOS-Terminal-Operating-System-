-- ╔══════════════════════════════════════╗
-- ║  TOS Kernel - Main Module            ║
-- ║  Orchestrates boot and main loop     ║
-- ╚══════════════════════════════════════╝

local computer = require("computer")
local component = require("component")

local kernel = {}

-- Kernel state
local running = false
local shuttingDown = false

-- Sub-modules (loaded during boot)
local log, hal, event, proc, fs, display

-- ============================================================
-- Boot sequence
-- ============================================================

function kernel.boot(opts)
  opts = opts or {}
  local earlyPrint = opts.earlyPrint or function() end

  -- ── Stage 1: Core modules ──────────────────────────────
  earlyPrint("  Loading kernel modules...", 0xAAAAAA)
  log = require("kernel.log")
  log.init({ earlyPrint = earlyPrint })
  log.info("kernel", "TOS Kernel v" .. _G._TOS.version .. " starting")

  -- ── Stage 2: Hardware detection ────────────────────────
  log.info("kernel", "Scanning hardware...")
  hal = require("kernel.hal")
  hal.scan()

  local info = hal.systemInfo()
  log.info("kernel", string.format("CPU T%d | GPU T%d | RAM T%d | %d components",
    info.cpuTier, info.gpuTier, info.memTier, info.components))

  if info.canNetwork then
    local wl = hal.checkWireless()
    info.hasWireless = wl
    log.info("kernel", "Network: " .. (wl and "Wireless" or "Wired") .. " modem detected")
  end
  if info.hasTunnel then
    log.info("kernel", "Linked card (tunnel) detected")
  end

  -- ── Stage 3: Filesystem ────────────────────────────────
  log.info("kernel", "Initializing filesystem...")
  fs = require("kernel.fs")
  fs.init(opts.bootFS)

  -- Auto-mount additional filesystems
  local fsList = hal.list("filesystem")
  local bootAddr = opts.bootFS and opts.bootFS.address
  for _, entry in ipairs(fsList) do
    if entry.address ~= bootAddr then
      -- Mount additional drives under /mnt/
      local label = "disk_" .. entry.address:sub(1, 4)
      if entry.proxy then
        local diskLabel = entry.proxy.getLabel()
        if diskLabel and diskLabel ~= "" then
          label = diskLabel
        end
      end
      local mountPoint = "/mnt/" .. label
      if not entry.proxy then
        entry.proxy = component.proxy(entry.address)
      end
      fs.mount(mountPoint, entry.proxy)
      log.info("kernel", "Mounted " .. entry.address:sub(1, 8) .. " at " .. mountPoint)
    end
  end

  -- Ensure core directories exist
  local coreDirs = {"/tmp", "/var", "/var/log", "/var/run", "/etc", "/usr", "/usr/bin", "/usr/modules"}
  for _, dir in ipairs(coreDirs) do
    if not fs.exists(dir) then
      fs.makeDirectory(dir)
    end
  end

  local diskFree = math.floor(fs.spaceFree("/") / 1024)
  local diskTotal = math.floor(fs.spaceTotal("/") / 1024)
  log.info("kernel", string.format("Boot disk: %dKB free / %dKB total", diskFree, diskTotal))
  if diskFree < 32 then
    log.warn("kernel", "WARNING: Very low disk space!")
  end

  -- ── Stage 4: System configuration ─────────────────────
  local sysconfig = nil
  do
    log.info("kernel", "Loading configuration...")
    local ok, mod = pcall(require, "kernel.config")
    if ok then
      sysconfig = mod
      sysconfig.init(fs)
      _G._TOS.config = sysconfig
      log.info("kernel", "Device profile: " .. sysconfig.deviceType())
      if sysconfig.get("verbose") then
        log.setLevel("DEBUG")
      end
    else
      log.warn("kernel", "Config module not available: " .. tostring(mod))
    end
  end

  -- ── Stage 5: Event system ──────────────────────────────
  log.info("kernel", "Starting event system...")
  event = require("kernel.event")

  -- Register hardware hot-plug handlers
  local SEAT_COMPONENT_TYPES = { screen = true, gpu = true, keyboard = true }

  event.on("component_added", function(_, addr, ctype)
    hal.handleComponentAdded(addr, ctype)
    log.info("hotplug", "Added: " .. ctype .. " [" .. addr:sub(1, 8) .. "]")
    if SEAT_COMPONENT_TYPES[ctype] then
      event.push("tos_seat_changed", "added", ctype, addr)
    end
  end, "kernel")

  event.on("component_removed", function(_, addr, ctype)
    hal.handleComponentRemoved(addr, ctype)
    log.info("hotplug", "Removed: " .. ctype .. " [" .. addr:sub(1, 8) .. "]")
    if SEAT_COMPONENT_TYPES[ctype] then
      event.push("tos_seat_changed", "removed", ctype, addr)
    end
  end, "kernel")

  -- ── Stage 6: Process manager ───────────────────────────
  log.info("kernel", "Starting process manager...")
  proc = require("kernel.process")

  -- ── Stage 7: Display system ────────────────────────────
  local isHeadless = sysconfig and sysconfig.isHeadless()
  if isHeadless then
    log.info("kernel", "Headless mode — skipping display init")
    -- Provide a stub display so code that calls display.* unconditionally
    -- doesn't crash. The stub silently discards all draw calls.
    display = {
      init = function() end, clear = function() end,
      fill = function() end, set = function() end,
      getSize = function() return 0, 0 end,
      getGpuTier = function() return 0 end,
      getGpuDepth = function() return 1 end,
      getTheme = function()
        return setmetatable({}, { __index = function() return 0xFFFFFF end })
      end,
      getGpu = function() return nil end,
      fit = function(s) return s or "" end,
      c = function() return 0xFFFFFF end,
    }
  else
    log.info("kernel", "Initializing display...")
    display = require("kernel.display")
    display.init(opts.gpu, opts.screenW, opts.screenH)
    log.info("kernel", string.format("Display: %dx%d, GPU Tier %d (%d-bit color)",
      opts.screenW or 0, opts.screenH or 0,
      display.getGpuTier(), display.getGpuDepth()))
  end

  -- ── Stage 8: Power monitor (optional) ─────────────────
  -- Only load optional modules if we have enough RAM
  -- Shell needs ~30KB to load, so keep at least 40KB free
  local MIN_FREE_FOR_OPTIONAL = 40960  -- 40KB

  do
    if computer.freeMemory() > MIN_FREE_FOR_OPTIONAL then
      local ok, powerMod = pcall(require, "kernel.power")
      if ok then
        powerMod.init({ log = log, config = sysconfig })
        _G._TOS.power = powerMod
        if sysconfig and sysconfig.isTablet() then
          event.interval(10, function() powerMod.check() end, "kernel:power")
          powerMod.onLow(function(level)
            if _G._TOS.audio then _G._TOS.audio.warning() else computer.beep(800, 0.3) end
          end)
          powerMod.onCritical(function(level)
            if _G._TOS.audio then _G._TOS.audio.critical() else computer.beep(400, 0.5) end
            log.fatal("power", "Battery critical!")
          end)
          log.info("kernel", "Tablet mode: battery monitoring active")
        end
      else
        log.warn("kernel", "Power module not available: " .. tostring(powerMod))
      end
    else
      log.warn("kernel", "Skipping power module (low memory: " ..
        math.floor(computer.freeMemory() / 1024) .. "KB free)")
    end
  end

  -- ── Stage 9: Security subsystem (optional) ────────────
  do
    if computer.freeMemory() > MIN_FREE_FOR_OPTIONAL then
      local ok1, crypto = pcall(require, "kernel.crypto")
      if ok1 then
        crypto.init()
        log.info("kernel", "Crypto: " .. (crypto.hasHardware() and "Hardware" or "Software"))

        local ok2, usersmod = pcall(require, "kernel.users")
        if ok2 then
          usersmod.init({ fs = fs, crypto = crypto, log = log })
          _G._TOS.users = usersmod

          local ok3, securefs = pcall(require, "kernel.securefs")
          if ok3 then
            securefs.init({ fs = fs, users = usersmod, log = log, process = proc })
            _G._TOS.securefs = securefs
            -- Kernel-boot session for securefs callers running before any
            -- user logs in. Cleared once a real user session exists.
            _G._TOS.bootSession = usersmod.kernelSession()
            log.info("kernel", "Security: users + securefs ready")

            -- Periodic session sweep (every 5 minutes)
            if event then
              event.interval(300, function() usersmod.sweepSessions() end, "kernel:session_sweep")
            end
          else
            log.warn("kernel", "SecureFS not available: " .. tostring(securefs))
          end
        else
          log.warn("kernel", "User system not available: " .. tostring(usersmod))
        end
      else
        log.warn("kernel", "Crypto not available: " .. tostring(crypto))
      end
    else
      log.warn("kernel", "Skipping security (low memory: " ..
        math.floor(computer.freeMemory() / 1024) .. "KB free)")
    end
  end

  -- ── Stage 10: Network (optional) ──────────────────────
  if (hal.has("modem") or hal.has("tunnel")) and computer.freeMemory() > MIN_FREE_FOR_OPTIONAL then
    local ok, netMod = pcall(require, "kernel.net")
    if ok then
      local initOk = pcall(netMod.init, {
        log    = log,
        config = sysconfig,
        event  = event,
        fs     = fs,
      })
      if initOk then
        _G._TOS.net = netMod
        log.info("kernel", "Network ready (" .. (netMod.getHostname()) .. ")")

        -- Initialize file transfer and remote shell handlers
        local trustMgr = netMod.getTrust()
        local cryptoMod = require("kernel.crypto")
        local netModules = {
          net = netMod, fs = fs, trust = trustMgr,
          crypto = cryptoMod, log = log, event = event,
        }
        local ok3, transferMod = pcall(require, "kernel.net.transfer")
        if ok3 then
          transferMod.init(netModules)
          log.info("kernel", "File transfer handler ready")
        end
        local ok4, remoteMod = pcall(require, "kernel.net.remote")
        if ok4 then
          remoteMod.init(netModules)
          log.info("kernel", "Remote shell handler ready")
        end
      else
        log.warn("kernel", "Network init failed")
      end
    else
      log.warn("kernel", "Network module not available: " .. tostring(netMod))
    end
  else
    if not (hal.has("modem") or hal.has("tunnel")) then
      log.info("kernel", "No network hardware - skipping")
    else
      log.warn("kernel", "Skipping network (low memory)")
    end
  end

  -- ── Stage 11: Startup services & compatibility ─────────
  -- Run startup scripts from /etc/rc.d/
  if computer.freeMemory() > MIN_FREE_FOR_OPTIONAL then
    local ok, rcMod = pcall(require, "kernel.rc")
    if ok then
      rcMod.init({ fs = fs, log = log, proc = proc })
      rcMod.runAll()
      _G._TOS.rc = rcMod
      log.info("kernel", "Startup services loaded")
      -- Service restart supervisor: check every 30s for crashed services
      if event then
        event.interval(30, function() rcMod.supervise() end, "kernel:rc_supervise")
      end
    end
  end

  -- Initialize cron scheduler
  if computer.freeMemory() > MIN_FREE_FOR_OPTIONAL then
    local ok, cronMod = pcall(require, "kernel.cron")
    if ok then
      cronMod.init({ fs = fs, log = log, event = event })
      _G._TOS.cron = cronMod
      log.info("kernel", "Cron scheduler initialized")
    end
  end

  -- Initialize user module manager.
  -- Always load the registry (so `mod list` works even on low RAM);
  -- only auto-start module code if there is enough memory.
  do
    local ok, modMgr = pcall(require, "kernel.modules")
    if ok then
      modMgr.init({ fs = fs, log = log, event = event })
      if computer.freeMemory() > 20480 then  -- 20KB — enough for most modules
        modMgr.startAll()
      else
        log.warn("kernel", "Low memory -- skipping module autostart (modules still registered)")
      end
      _G._TOS.modules = modMgr
      log.info("kernel", "Module manager initialized")
    end
  end

  -- Load OpenOS compatibility layer (allows OPPM and OpenOS programs to run)
  if computer.freeMemory() > MIN_FREE_FOR_OPTIONAL then
    local ok, compatMod = pcall(require, "compat")
    if ok then
      local loaded2, failed2 = compatMod.init({ procSleep = proc.sleep })
      _G._TOS.compat = compatMod
      log.info("kernel", string.format("OpenOS compat: %d modules loaded, %d failed", loaded2, failed2))
    else
      log.warn("kernel", "OpenOS compat not available")
    end
  end

  -- ── Stage 12: Audio feedback system ─────────────────────
  do
    local ok, audioMod = pcall(require, "kernel.audio")
    if ok then
      audioMod.init(sysconfig)
      _G._TOS.audio = audioMod
      log.info("kernel", "Audio feedback: " .. (audioMod.isEnabled() and "enabled" or "disabled"))
    else
      log.info("kernel", "Audio module not available")
    end
  end

  -- ── Stage 13: Boot complete ─────────────────────────────
  local freeNow = computer.freeMemory()
  local bootDuration = computer.uptime() - _G._TOS.bootTime
  log.info("kernel", "Boot complete! Free memory: " ..
    math.floor(freeNow / 1024) .. "KB")
  log.info("kernel", string.format("Boot time: %.1fs", bootDuration))

  if freeNow < 20480 then
    log.warn("kernel", "LOW MEMORY: " .. math.floor(freeNow / 1024) .. "KB free!")
  end

  earlyPrint(string.format("  Boot complete: %.1fs, %dK free",
    bootDuration, math.floor(freeNow / 1024)), 0x00FF00)

  -- Boot success sound
  if _G._TOS.audio then _G._TOS.audio.bootComplete() end

  if not isHeadless then
    -- Pause so user can read boot messages
    computer.pullSignal(1.5)
  end

  -- Stop routing log messages to the GPU (shell owns the screen now)
  log.detachEarlyPrint()

  -- ── Stage 14: Login → Shell / Headless Loop ─────────────
  if isHeadless then
    kernel.headlessMain()
  else
    kernel.loginAndStartShell()
  end
end

-- ============================================================
-- Login + Shell launcher
-- ============================================================

function kernel.loginAndStartShell()
  running = true

  local usersmod = _G._TOS.users
  local securefs = _G._TOS.securefs
  local freeMem = computer.freeMemory()

  -- ── Minimal auth (works even with no login module) ────
  -- SECURITY: Always require password. RAM removal must NOT
  -- grant access. Uses zero extra modules, theme-aware.
  local function minimalAuth()
    local W, H = display.getSize()
    local T = display.getTheme()
    display.clear(T.bg)
    display.set(2, 2, "TOS - Authentication Required", T.title, T.bg)
    display.set(2, 3, "Low memory mode. Enter root password.", T.dim, T.bg)
    display.set(2, 5, "Password: ", T.dim, T.bg)

    local maxAttempts = 5
    for attempt = 1, maxAttempts do
      display.fill(12, 5, W - 13, 1, " ", T.fg, T.bg)
      local buf = ""
      while true do
        display.set(12, 5, string.rep("*", #buf) .. "_ ", T.fg, T.bg)
        local sig, _, ch, co = computer.pullSignal(0.5)
        if sig == "key_down" then
          if co == 28 then break
          elseif co == 14 then if #buf > 0 then buf = buf:sub(1, -2) end
          elseif ch and ch >= 32 and ch < 127 then buf = buf .. string.char(ch)
          end
        end
      end

      if usersmod then
        local token = usersmod.login("root", buf)
        if token then
          display.set(2, 7, "Access granted.", T.success, T.bg)
          computer.pullSignal(0.5)
          return token
        end
      else
        if buf == "root" then
          display.set(2, 7, "Emergency access (no auth module).", T.warning, T.bg)
          computer.pullSignal(0.5)
          return "emergency"
        end
      end

      local remain = maxAttempts - attempt
      if remain > 0 then
        display.set(2, 7, "Wrong password. " .. remain .. " attempts left.", T.error, T.bg)
        display.fill(12, 5, W - 13, 1, " ", T.fg, T.bg)
        computer.pullSignal(1.5)
        display.fill(2, 7, W - 3, 1, " ", T.fg, T.bg)
      end
    end

    display.set(2, 7, "Too many attempts. Rebooting...", T.error, T.bg)
    if _G._TOS.audio then _G._TOS.audio.critical() else computer.beep(400, 0.5) end
    computer.pullSignal(3)
    kernel.reboot()
    return nil
  end

  -- ── Decide auth path ──────────────────────────────────
  local loginScreen = nil
  local useMinimalAuth = false

  if freeMem < 32768 then
    log.warn("kernel", "Low memory - using minimal auth")
    useMinimalAuth = true
  else
    local ok, mod = pcall(require, "shell.login")
    if ok then
      loginScreen = mod
    else
      log.warn("kernel", "Login module not available: " .. tostring(mod))
      useMinimalAuth = true
    end
  end

  local shellModule = nil
  do
    -- Use "shell.init" (not "shell") to avoid collision with the OpenOS
    -- compat shim, which registers package.loaded["shell"] = shell_api.
    local ok, mod = pcall(require, "shell.init")
    if ok then
      shellModule = mod
    else
      log.error("kernel", "Shell module failed: " .. tostring(mod))
    end
  end

  -- ── Per-seat helpers ──────────────────────────────────
  local screenMod = require("kernel.screen")
  local shellCaps = {
    ["fs.read"]   = true,
    ["fs.write"]  = true,
    ["compat.io"] = true,
    ["component"] = true,
    ["load"]      = true,
    ["net"]       = true,
  }

  -- Per-seat state: session tokens and shell PIDs indexed by display
  local sessionTokens = {}
  local shellPIDs = {}

  --- Spawn a login process on a specific display.
  -- On successful auth, pushes tos_login_complete(dIdx, token).
  local function spawnLoginProcess(dIdx)
    local dProxy = screenMod.displayProxy(dIdx)
    if not dProxy then return nil end
    return proc.spawn("login@" .. dIdx, function()
      local token = nil
      if useMinimalAuth then
        token = minimalAuth()
      elseif loginScreen then
        local ok, result = pcall(loginScreen.run, {
          display = dProxy,
          event   = event,
          users   = usersmod,
          proc    = proc,
          log     = log,
        })
        if ok then
          token = result
        else
          log.error("kernel", "Login error on display " .. dIdx .. ": " .. tostring(result))
          token = minimalAuth()
        end
      end
      if token then
        sessionTokens[dIdx] = token
        shellPIDs[dIdx] = spawnShellForSeat(dIdx, token)
        _G._TOS.shellPIDs = shellPIDs
        _G._TOS.shellPID = _G._TOS.shellPID or shellPIDs[dIdx]
      end
    end, {
      display  = dIdx,
      priority = 2,
      source   = "kernel",
    })
  end

  --- Spawn a shell for a seat that has completed login.
  spawnShellForSeat = function(dIdx, token)
    local dProxy = screenMod.displayProxy(dIdx)
    if not dProxy or not shellModule then return nil end

    local userName = "root"
    local shellSession = nil
    if token and usersmod then
      shellSession = usersmod.getSession(token)
      if shellSession then userName = shellSession.user end
    end
    if not shellSession then
      shellSession = usersmod and usersmod.kernelSession() or nil
    end

    local kernelCopy = setmetatable(
      {
        display = dProxy,
        displayIdx = dIdx,
        getDisplay = function() return dProxy end,
        getDisplayIdx = function() return dIdx end,
      },
      { __index = kernel }
    )

    log.info("kernel", "Seat " .. dIdx .. ": shell for " .. userName)

    local pid = proc.spawn("shell:" .. userName .. "@" .. dIdx, function()
      local ok2, err2 = pcall(shellModule.run, kernelCopy, token)
      if not ok2 then
        local msg = tostring(err2)
        log.error("kernel", "Shell crashed on display " .. dIdx .. ": " .. msg)
        if dProxy then
          local sW, sH = dProxy.getSize()
          local sT = dProxy.getTheme()
          dProxy.fill(1, 2, sW, 3, " ", sT.fg, sT.bg)
          dProxy.set(2, 2, "Shell crashed:", sT.error, sT.bg)
          dProxy.set(2, 3, dProxy.fit(msg, sW - 2), sT.dim, sT.bg)
          computer.pullSignal(2)
        end
      end
      -- Shell exited naturally — signal kernel to respawn login for this seat
      event.push("tos_shell_exited", dIdx)
    end, {
      priority  = 1,
      source    = "kernel",
      tsr       = false,
      principal = shellSession,
      token     = token,
      cwd       = shellSession and shellSession.home or "/",
      caps      = shellCaps,
      display   = dIdx,
    })
    proc.setForeground(pid, dIdx)
    return pid
  end

  -- ── Main session loop ──────────────────────────────────
  if shellModule then
    local displayCount = screenMod.count()
    local spawnShellForSeat
    -- Spawn initial login process on each display
    for dIdx = 1, displayCount do
      spawnLoginProcess(dIdx)
    end

    _G._TOS.shellPIDs = shellPIDs
    _G._TOS.shellPID = nil  -- set once first shell spawns

    if displayCount > 1 then
      log.info("kernel", "Multi-seat: " .. displayCount .. " displays active")
    end

    -- Main kernel loop
    local lastCtrlC = {}  -- per-display Ctrl+C timing
    while running do
      local signal = table.pack(event.pull(0.05))

      if signal[1] == "tos_shutdown" then
        running = false
        break
      end

      -- ── Per-seat login complete: spawn shell ──
      if signal[1] == "tos_login_complete" then
        local dIdx = signal[2]
        local token = signal[3]
        if dIdx and token then
          sessionTokens[dIdx] = token
          shellPIDs[dIdx] = spawnShellForSeat(dIdx, token)
          _G._TOS.shellPIDs = shellPIDs
          _G._TOS.shellPID = _G._TOS.shellPID or shellPIDs[dIdx]
        end
        signal = table.pack(nil)
      end

      -- ── Per-seat logout: kill shell, respawn login ──
      if signal[1] == "tos_logout" then
        local logoutIdx = signal[2]
        if logoutIdx then
          -- Seat-local logout
          if shellPIDs[logoutIdx] then
            proc.kill(shellPIDs[logoutIdx])
            shellPIDs[logoutIdx] = nil
          end
          if usersmod and sessionTokens[logoutIdx] then
            usersmod.logout(sessionTokens[logoutIdx])
            sessionTokens[logoutIdx] = nil
          end
          log.info("kernel", "Seat " .. logoutIdx .. ": logged out")
          spawnLoginProcess(logoutIdx)
        else
          -- Global logout (all seats)
          for dIdx, pid in pairs(shellPIDs) do
            proc.kill(pid)
            if usersmod and sessionTokens[dIdx] then
              usersmod.logout(sessionTokens[dIdx])
            end
          end
          shellPIDs = {}
          sessionTokens = {}
          log.info("kernel", "All seats logged out")
          break
        end
        signal = table.pack(nil)
      end

      -- ── Shell exited naturally on a seat: respawn login ──
      if signal[1] == "tos_shell_exited" then
        local dIdx = signal[2]
        if dIdx and not shellPIDs[dIdx] then
          -- Shell already cleaned up (logout handled it); skip
        elseif dIdx then
          shellPIDs[dIdx] = nil
          if usersmod and sessionTokens[dIdx] then
            usersmod.logout(sessionTokens[dIdx])
            sessionTokens[dIdx] = nil
          end
          log.info("kernel", "Seat " .. dIdx .. ": shell exited, respawning login")
          spawnLoginProcess(dIdx)
        end
        signal = table.pack(nil)
      end

      -- ── Seat-local hotkey: Ctrl+C = interrupt foreground ──
      -- Ctrl+C sends char=3 in OC; signal[2] = keyboard address
      if signal[1] == "key_down" and signal[3] == 3 then
        local ctrlDIdx = 1
        if screenMod.displayForKeyboard then
          ctrlDIdx = screenMod.displayForKeyboard(signal[2]) or 1
        end
        local fg = proc.getForeground(ctrlDIdx)
        local now = computer.uptime()
        if fg then
          if lastCtrlC[ctrlDIdx] and (now - lastCtrlC[ctrlDIdx]) < 1.5 then
            proc.kill(fg)
            lastCtrlC[ctrlDIdx] = nil
            log.warn("kernel", "Killed PID " .. fg .. " via double Ctrl+C on display " .. ctrlDIdx)
          else
            proc.signal(fg, "tos_interrupt")
            lastCtrlC[ctrlDIdx] = now
          end
        end
        signal = table.pack(nil)
      end

      -- ── Seat-local hotkey: Ctrl+T = task switcher dialog ──
      -- Ctrl+T sends char=20 in OC
      if signal[1] == "key_down" and signal[3] == 20 then
        local ctrlTIdx = 1
        if screenMod.displayForKeyboard then
          ctrlTIdx = screenMod.displayForKeyboard(signal[2]) or 1
        end
        kernel.taskSwitcher(ctrlTIdx)
        signal = table.pack(nil)
      end

      -- ── Hot-plug: seat added/removed ──
      if signal[1] == "tos_seat_changed" then
        local added, removed = screenMod.rebuild()
        for _, dIdx in ipairs(removed) do
          if shellPIDs[dIdx] then
            proc.kill(shellPIDs[dIdx])
            shellPIDs[dIdx] = nil
          end
          if sessionTokens[dIdx] then
            if usersmod then usersmod.logout(sessionTokens[dIdx]) end
            sessionTokens[dIdx] = nil
          end
          log.warn("hotplug", "Display " .. dIdx .. " removed")
        end
        for _, dIdx in ipairs(added) do
          spawnLoginProcess(dIdx)
          log.info("hotplug", "Display " .. dIdx .. " added, spawning login")
        end
        signal = table.pack(nil)
      end

      proc.tick(signal.n > 0 and signal or nil)

      if proc.count() == 0 then
        log.warn("kernel", "All processes terminated")
        for dIdx, token in pairs(sessionTokens) do
          if usersmod then usersmod.logout(token) end
        end
        break
      end
    end
  else
    -- Emergency shell - run directly on main thread
    -- (NOT as a coroutine - signal delivery is unreliable through proc.tick)
    kernel.emergencyShell()
    running = false
  end

  kernel.shutdown()
end

-- ============================================================
-- Task Switcher Dialog (Ctrl+T)
-- ============================================================

function kernel.taskSwitcher(displayIdx)
  -- Resolve the display to draw on: seat-local proxy or global display
  local screenMod = require("kernel.screen")
  local dsp = displayIdx and screenMod.displayProxy(displayIdx) or display
  if not dsp or not proc then return end

  local W, H = dsp.getSize()
  local T = dsp.getTheme()
  local procs = proc.list()
  if #procs == 0 then return end

  -- When seat-local, only show processes on this display (+ system processes)
  if displayIdx then
    local filtered = {}
    for _, p in ipairs(procs) do
      if not p.display or p.display == displayIdx then
        filtered[#filtered + 1] = p
      end
    end
    procs = filtered
    if #procs == 0 then return end
  end

  local sel = 1
  -- Pre-select the current foreground process
  local fgPID = proc.getForeground(displayIdx)
  for i, p in ipairs(procs) do
    if p.pid == fgPID then sel = i; break end
  end

  -- Dialog dimensions
  local dw = math.min(48, W - 4)
  local maxList = math.min(#procs, H - 8)
  local dh = maxList + 6
  local dx = math.floor((W - dw) / 2) + 1
  local dy = math.floor((H - dh) / 2) + 1
  local scroll = 0

  local function drawSwitcher()
    dsp.dbox(dx, dy, dw, dh, "Task Switcher", {
      border = T.border, bg = T.panel_bg, title = T.title,
    })

    -- Column headers
    local hdr = string.format(" %-4s %-16s %-7s %s", "PID", "Name", "State", "CPU")
    dsp.set(dx + 1, dy + 1, hdr:sub(1, dw - 2), T.dim, T.panel_bg)

    -- Process list
    for row = 1, maxList do
      local idx = scroll + row
      local y = dy + 1 + row
      if idx <= #procs then
        local p = procs[idx]
        local fg_marker = (p.pid == fgPID) and "*" or " "
        local state = p.tsr and "TSR" or p.state:sub(1, 7)
        local line = string.format("%s%-4d %-16s %-7s %.1fs",
          fg_marker, p.pid, p.name:sub(1, 16), state, p.cpuTime or 0)
        if idx == sel then
          dsp.set(dx + 1, y, dsp.fit(line, dw - 2), T.sel_fg, T.sel_bg)
        else
          local color = T.fg
          if p.tsr then color = T.dim end
          if p.pid == fgPID then color = T.highlight end
          dsp.set(dx + 1, y, dsp.fit(line, dw - 2), color, T.panel_bg)
        end
      else
        dsp.fill(dx + 1, y, dw - 2, 1, " ", T.fg, T.panel_bg)
      end
    end

    -- Help bar
    local helpY = dy + dh - 2
    local help = " [Enter]Switch [T]SR [K]ill [^Q]Close"
    dsp.set(dx + 1, helpY, dsp.fit(help, dw - 2), T.dim, T.panel_bg)
  end

  drawSwitcher()

  while true do
    local sig, _, ch, co = computer.pullSignal(0.5)
    if sig == "key_down" then
      if ch == 17 or ch == 113 then  -- Ctrl+Q or q = close
        break
      elseif co == 200 then  -- Up
        if sel > 1 then
          sel = sel - 1
          if sel <= scroll then scroll = sel - 1 end
          drawSwitcher()
        end
      elseif co == 208 then  -- Down
        if sel < #procs then
          sel = sel + 1
          if sel > scroll + maxList then scroll = sel - maxList end
          drawSwitcher()
        end
      elseif co == 28 then  -- Enter = switch to selected process
        local p = procs[sel]
        if p then
          proc.setForeground(p.pid, displayIdx)
          proc.signal(p.pid, "tos_focus")
          log.info("kernel", "Switched to PID " .. p.pid .. " (" .. p.name .. ")")
        end
        break
      elseif ch == 107 or ch == 75 then  -- k/K = kill selected
        local p = procs[sel]
        if p and p.pid ~= fgPID then  -- Don't kill the shell you're in
          proc.kill(p.pid)
          log.warn("kernel", "Killed PID " .. p.pid .. " from task switcher")
          procs = proc.list()
          if displayIdx then
            local filtered = {}
            for _, pp in ipairs(procs) do
              if not pp.display or pp.display == displayIdx then
                filtered[#filtered + 1] = pp
              end
            end
            procs = filtered
          end
          if sel > #procs then sel = math.max(1, #procs) end
          if #procs == 0 then break end
          drawSwitcher()
        end
      elseif ch == 116 or ch == 84 then  -- t/T = toggle TSR
        local p = procs[sel]
        if p then
          local pObj = proc.get(p.pid)
          if pObj then
            if pObj.tsr then
              pObj.tsr = false
              pObj.state = proc.STATE.READY
            else
              proc.goTSR(p.pid)
            end
            procs = proc.list()
            if displayIdx then
              local filtered = {}
              for _, pp in ipairs(procs) do
                if not pp.display or pp.display == displayIdx then
                  filtered[#filtered + 1] = pp
                end
              end
              procs = filtered
            end
            drawSwitcher()
          end
        end
      end
    end
  end

  -- Signal foreground process to redraw after dialog closes
  local fg = proc.getForeground(displayIdx)
  if fg then proc.signal(fg, "tos_focus") end
end

-- ============================================================
-- Emergency Shell (when main shell can't load)
-- ============================================================

function kernel.emergencyShell()
  if not display then return end

  -- ── Emergency auth gate ───────────────────────────────
  local usersmod = _G._TOS.users
  local W0, H0 = display.getSize()
  local T0 = display.getTheme()

  display.clear(T0.bg)
  display.set(2, 2, "TOS EMERGENCY - Auth Required", T0.error, T0.bg)
  display.set(2, 3, "Password: ", T0.dim, T0.bg)

  local authed = false
  for attempt = 1, 3 do
    display.fill(12, 3, W0 - 13, 1, " ", T0.fg, T0.bg)
    local buf = ""
    while true do
      display.set(12, 3, string.rep("*", #buf) .. "_ ", T0.fg, T0.bg)
      local sig, _, ch, co = computer.pullSignal(0.5)
      if sig == "key_down" then
        if co == 28 then break
        elseif co == 14 then if #buf > 0 then buf = buf:sub(1, -2) end
        elseif ch and ch >= 32 and ch < 127 then buf = buf .. string.char(ch) end
      end
    end
    if usersmod then
      local token = usersmod.login("root", buf)
      if token then authed = true break end
    else
      if buf == "root" then authed = true break end
    end
    if attempt < 3 then
      display.set(2, 5, "Wrong. " .. (3 - attempt) .. " left.", T0.error, T0.bg)
      computer.pullSignal(1.5)
      display.fill(2, 5, W0 - 3, 1, " ", T0.fg, T0.bg)
    end
  end
  if not authed then
    display.set(2, 5, "Locked. Rebooting...", T0.error, T0.bg)
    computer.pullSignal(3)
    kernel.reboot()
    return
  end

  -- ── Emergency shell ───────────────────────────────────

  local W, H = display.getSize()
  local T = display.getTheme()
  -- Line buffer: stores {text, color} for every line ever printed
  local lines = {}
  local scrollOff = 0
  local HEADER = 3
  local viewH = H - HEADER - 1

  local function redraw()
    display.clear(T.bg)
    display.set(2, 1, "TOS EMERGENCY SHELL", T.error, T.bg)
    display.set(2, 2, "Main shell could not load.", T.warning, T.bg)
    display.set(2, 3, "'help' for list.", T.dim, T.bg)
    local startIdx = #lines - viewH - scrollOff + 1
    if startIdx < 1 then startIdx = 1 end
    for row = 1, viewH do
      local idx = startIdx + row - 1
      local y = HEADER + row
      if idx >= 1 and idx <= #lines then
        local ln = lines[idx]
        display.fill(1, y, W, 1, " ", T.fg, T.bg)
        display.set(1, y, ln[1]:sub(1, W), ln[2] or T.dim, T.bg)
      else
        display.fill(1, y, W, 1, " ", T.fg, T.bg)
      end
    end
  end

  local function ePrint(text, color)
    lines[#lines + 1] = {tostring(text), color or T.dim}
    scrollOff = 0
    redraw()
  end

  local function prompt()
    local promptY = H
    display.fill(1, promptY, W, 1, " ", T.fg, T.bg)
    display.set(1, promptY, "> ", T.prompt, T.bg)
    local buf = ""
    while true do
      display.fill(3, promptY, W - 3, 1, " ", T.fg, T.bg)
      display.set(3, promptY, buf, T.fg, T.bg)
      display.set(3 + #buf, promptY, "_", T.prompt, T.bg)
      local sig, _, char, code = computer.pullSignal(0.5)
      if sig == "key_down" then
        if code == 28 then  -- Enter
          return buf
        elseif code == 14 then  -- Backspace
          if #buf > 0 then buf = buf:sub(1, -2) end
        elseif char and char >= 32 and char < 127 then
          buf = buf .. string.char(char)
        end
      end
    end
  end

  while true do
    local input = prompt()
    local parts = {}
    for w in input:gmatch("%S+") do parts[#parts + 1] = w end
    local cmd = parts[1] and parts[1]:lower() or ""

    if cmd == "help" then
      ePrint("Emergency commands:", T.title)
      ePrint("  ls [path]   - List files")
      ePrint("  cat <file>  - Show file")
      ePrint("  mem         - Memory info")
      ePrint("  verify      - Check system files")
      ePrint("  reboot      - Reboot system")
      ePrint("  shutdown    - Shut down")
    elseif cmd == "ls" then
      local path = parts[2] or "/"
      local ok2, list = pcall(fs.list, path)
      if ok2 and list then
        if type(list) == "table" then
          for _, name in ipairs(list) do ePrint("  " .. name) end
        elseif type(list) == "function" then
          for name in list do ePrint("  " .. name) end
        end
      else
        ePrint("Cannot list: " .. path, T.error)
      end
    elseif cmd == "cat" then
      if parts[2] then
        local content = fs.readFile(parts[2])
        if content then
          for line in content:gmatch("[^\n]*") do ePrint(line) end
        else
          ePrint("Cannot read: " .. parts[2], T.error)
        end
      end
    elseif cmd == "mem" then
      ePrint(string.format("Free: %dKB / Total: %dKB",
        math.floor(computer.freeMemory() / 1024),
        math.floor(computer.totalMemory() / 1024)))
    elseif cmd == "verify" then
      kernel.verifySystem(ePrint)
    elseif cmd == "reboot" then
      kernel.reboot()
      return
    elseif cmd == "shutdown" then
      kernel.shutdown()
      return
    elseif cmd ~= "" then
      ePrint("Unknown: " .. cmd, T.warning)
    end
  end
end

-- ============================================================
-- System verification (checks all expected files)
-- ============================================================

function kernel.verifySystem(printFn)
  printFn = printFn or function() end

  -- Resolve colors via display theme if available
  local cOK  = display and display.c("success") or 0xFFFFFF
  local cWrn = display and display.c("warning") or 0xFFFFFF
  local cErr = display and display.c("error") or 0xFFFFFF
  local cDim = display and display.c("dim") or 0xFFFFFF

  -- Load file list from centralized manifest (single source of truth)
  local allFiles
  do
    local ok2, manifest = pcall(require, "system_manifest")
    if ok2 and type(manifest) == "table" then
      allFiles = manifest
    else
      -- Fallback: minimal list if manifest missing
      allFiles = {
        { path = "/init.lua",              critical = true },
        { path = "/tos/kernel/init.lua",   critical = true },
        { path = "/tos/shell/init.lua",    critical = true },
      }
      printFn("  WARN: system_manifest.lua not found, using minimal verify list", cWrn)
    end
  end

  local ok, missing, damaged = 0, 0, 0

  for _, file in ipairs(allFiles) do
    if fs.exists(file.path) then
      local content = fs.readFile(file.path)
      if content then
        local fn, loadErr = load(content, "=" .. file.path)
        if fn then
          printFn("  OK  " .. file.path, cOK)
          ok = ok + 1
        else
          local reason = "error"
          if loadErr then
            if loadErr:find("memory") then reason = "low RAM"
            else reason = "syntax" end
          end
          printFn("  BAD " .. file.path .. " (" .. reason .. ")", cWrn)
          if loadErr then
            printFn("      " .. tostring(loadErr), cDim)
          end
          damaged = damaged + 1
        end
      else
        printFn("  BAD " .. file.path .. " (unreadable)", cErr)
        damaged = damaged + 1
      end
    else
      local tag = file.critical and "MISS" or "skip"
      local color = file.critical and cErr or cWrn
      printFn("  " .. tag .. " " .. file.path, color)
      missing = missing + 1
    end
  end

  printFn("", cDim)
  printFn(string.format("Result: %d OK, %d missing, %d damaged", ok, missing, damaged), cDim)

  return missing == 0 and damaged == 0
end

-- ============================================================
-- Kernel API (exposed to processes)
-- ============================================================

function kernel.getLog()      return log end
function kernel.getHAL()      return hal end
function kernel.getEvent()    return event end
function kernel.getProc()     return proc end
--- Return the user-facing filesystem (permission-checked).
-- Historically this returned the raw `kernel.fs`; as of Phase 1 it
-- returns securefs so every caller inherits ACL enforcement.
function kernel.getFS()
  return _G._TOS.securefs or fs
end
--- Return the raw, privilege-bypassing filesystem.
-- Only kernel code (rc.lua, module loader, boot stages) should use this.
function kernel.getPrivilegedFS() return fs end
function kernel.getDisplay()  return display end
function kernel.getDisplayIdx() return nil end  -- global kernel has no specific display
function kernel.getUsers()    return _G._TOS.users end
function kernel.getSecureFS() return _G._TOS.securefs end
function kernel.getCrypto()
  local ok, mod = pcall(require, "kernel.crypto")
  return ok and mod or nil
end
function kernel.getConfig()   return _G._TOS.config end
function kernel.getPower()    return _G._TOS.power end
function kernel.getNet()      return _G._TOS.net end

function kernel.uptime()
  return computer.uptime() - _G._TOS.bootTime
end

function kernel.memUsage()
  local total = computer.totalMemory()
  local free = computer.freeMemory()
  return {
    total = total,
    free  = free,
    used  = total - free,
    pct   = math.floor((total - free) / total * 100),
  }
end

function kernel.shutdown(reboot)
  running = false
  shuttingDown = true

  if log then
    log.info("kernel", reboot and "Rebooting..." or "Shutting down...")
  end

  -- Stop cron scheduler
  if _G._TOS.cron then
    pcall(_G._TOS.cron.shutdown)
  end

  -- Stop user modules
  if _G._TOS.modules then
    pcall(_G._TOS.modules.stopAll)
  end

  -- Stop startup services
  if _G._TOS.rc then
    pcall(_G._TOS.rc.stopAll)
  end

  -- Kill all processes
  if proc then
    for _, p in ipairs(proc.list()) do
      proc.kill(p.pid)
    end
  end

  -- Shut down network
  if _G._TOS.net then
    _G._TOS.net.shutdown()
  end

  -- Clear screen
  if display then
    local T = display.getTheme()
    display.clear(T.bg)
    display.set(2, 2, reboot and "Rebooting TOS..." or "TOS shut down.", T.success, T.bg)
    display.set(2, 3, "Goodbye!", T.dim, T.bg)
  end

  -- Shutdown audio feedback
  if _G._TOS.audio then _G._TOS.audio.shutdown() end

  computer.pullSignal(0.5)
  computer.shutdown(reboot or false)
end

function kernel.reboot()
  kernel.shutdown(true)
end

function kernel.isRunning()
  return running
end

function kernel.version()
  return _G._TOS.version, _G._TOS.codename
end

-- ============================================================
-- Headless Main Loop (server blades / dedicated service hosts)
-- ============================================================
-- Runs in place of loginAndStartShell when the device has no GPU/screen.
-- No login screen, no shell TUI. The kernel auto-starts as _kernel_ and
-- enters a service-tick loop. Network commands (rsh / remote) are the
-- primary way to interact with a headless server.
--
-- Recovery: if a screen+keyboard are hot-plugged, the loop detects it
-- and offers to switch to interactive mode.

function kernel.headlessMain()
  running = true

  local usersmod = _G._TOS.users

  -- Bind the kernel session so all service processes inherit root
  -- permissions (securefs, securefs.forSession, etc.)
  if usersmod then
    _G._TOS.bootSession = usersmod.kernelSession()
  end

  log.info("kernel", "Entering headless service loop")

  -- Ensure network is up — a server without a modem is user-error.
  if not _G._TOS.net then
    log.warn("kernel", "WARNING: headless server has no network!")
    log.warn("kernel", "Install a modem or linked card so the server can be reached.")
  end

  -- Headless tick: pump events, run process scheduler, handle signals.
  while running do
    local signal = table.pack(event.pull(0.5))

    if signal[1] == "tos_shutdown" then
      running = false
      break
    end

    -- Hot-plug recovery: if a screen+gpu+keyboard appear, offer to
    -- switch to interactive mode. This handles the case where a user
    -- physically attaches a terminal to diagnose issues.
    if signal[1] == "component_added" then
      local ctype = signal[3]
      if ctype == "screen" or ctype == "gpu" or ctype == "keyboard" then
        log.info("kernel", "Display hardware detected — checking for interactive switch")
        -- Wait a moment for all three to register
        computer.pullSignal(0.5)
        local component2 = require("component")
        local hasGPU    = component2.list("gpu")() ~= nil
        local hasScreen = component2.list("screen")() ~= nil
        local hasKB     = component2.list("keyboard")() ~= nil
        if hasGPU and hasScreen and hasKB then
          log.info("kernel", "Full display hardware present — switching to interactive mode")
          running = false
          -- Re-init display for real this time
          display = require("kernel.display")
          local gpu = component2.proxy(component2.list("gpu")())
          if gpu then
            local w, h = gpu.maxResolution()
            display.init(gpu, w, h)
          end
          kernel.loginAndStartShell()
          return
        end
      end
    end

    -- Tick processes (services, background tasks, net handlers)
    proc.tick(signal.n > 0 and signal or nil)
  end

  kernel.shutdown()
end

return kernel
