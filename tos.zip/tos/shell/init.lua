-- TOS Shell - TUI-first launcher
-- Boots directly into the primary TUI (shell/panels.lua).
-- Falls back to a minimal CLI if the TUI cannot load or the user
-- explicitly chooses "Shell" from the F10 quit menu.
local computer = require("computer")
local S, K, E, P, F, D, U, SC, NM = {}, nil, nil, nil, nil, nil, nil, nil, nil
local W, H, cwd, who, st = 80, 25, "/", "root", nil

local function pullSignal()
  if coroutine.isyieldable and coroutine.isyieldable() then
    return coroutine.yield()
  end
  return computer.pullSignal(0.05)
end

-- ── Minimal CLI fallback ─────────────────────────────────
-- Used only when panels.lua is unavailable or the user exits to CLI.
local function cliLoop()
  local cy = 3
  local hi = {}

  local function scr()
    if cy > H - 2 then
      local g = D.getGpu()
      if g then
        local ok = pcall(g.copy, 1, 4, W, H-5, 0, -1)
        if ok then g.fill(1, H-2, W, 1, " ") cy = H-2
        else D.fill(1, 3, W, H-4, " ", D.c("fg"), D.c("bg")); cy = 3 end
      else cy = 3 end
    end
  end

  local function o(t, c)
    scr()
    local s = tostring(t):sub(1, W)
    D.fill(1, cy, W, 1, " ", D.c("fg"), D.c("bg"))
    D.set(1, cy, s, c or D.c("fg"), D.c("bg"))
    cy = cy + 1
  end

  local function redraw()
    D.clear(D.c("bg"))
    D.fill(1, 1, W, 1, " ", D.c("bar_fg"), D.c("bar_bg"))
    D.set(2, 1, " TOS CLI Mode - type 'tui' to return to TUI", D.c("bar_fg"), D.c("bar_bg"))
    D.fill(1, H, W, 1, " ", D.c("bar_fg"), D.c("bar_bg"))
    local bar = " [tui] TUI  [help] Commands  [logout]"
    D.set(2, H, bar:sub(1, W - 2), D.c("bar_fg"), D.c("bar_bg"))
    cy = 3
  end

  local function rp(p)
    if not p or p == "" then return cwd end
    if p:sub(1,1) == "/" then return p end
    return F.join(cwd, p)
  end

  -- Session info for permission checks
  local userTier = 3  -- default ROOT
  if U and st then
    local sess = U.getSession(st)
    if sess then userTier = sess.tier or 3 end
  end
  local comp = require("component")

  -- ── Full command set (matches TUI) ──────────────────────
  local C = {}

  -- ── Help ────────────────────────────────────────────────
  C.help = function(a)
    local topic = a and a[1] and a[1]:lower()
    if topic then
      -- Delegate to the same help topics as TUI
      local topics = {
        cp = { "cp <src> <dst> - Copy a file." },
        mv = { "mv <src> <dst> - Move or rename." },
        cd = { "cd [dir] - Change directory. (.., ~)" },
        find = { "find [path] [-name pattern]" },
        grep = { "grep <pattern> <file>" },
        edit = { "edit <file> - Open in TUI editor." },
        run = { "run <file.lua> [args] - Execute Lua file." },
        tape = { "tape [detect|info|label|store|restore|list|dump|erase]" },
      }
      local t = topics[topic]
      if t then for _, l in ipairs(t) do o(l) end
      else o("No detailed help for: " .. topic, D.c("dim")) end
      return
    end
    o("=== TOS CLI Commands ===", D.c("title"))
    o("")
    o(" Navigation & Files", D.c("highlight"))
    o("  cd ls cat more mkdir touch cp mv rm")
    o("  find grep wc echo df")
    o("")
    o(" Editor & Execution", D.c("highlight"))
    o("  edit run bg lua")
    o("")
    o(" System", D.c("highlight"))
    o("  mem ver about hw ps kill uptime log")
    o("  verify programs history tutorial")
    o("")
    o(" Session & Users", D.c("highlight"))
    o("  whoami passwd users useradd userdel usermod")
    o("  logout reboot shutdown")
    o("")
    o(" Devices & Environment", D.c("highlight"))
    o("  lsdev mount umount env service cron")
    o("")
    o(" Peripherals", D.c("highlight"))
    o("  redstone robot inventory component tape")
    o("")
    if NM then
    o(" Network", D.c("highlight"))
    o("  net ping hostname chat rsh scp screen")
    o("")
    end
    o(" Modules & Disks", D.c("highlight"))
    o("  mod disk deploy compat")
    o("")
    o(" Other: cls tui (return to TUI)")
  end

  C.ver = function() o("TOS v" .. (_G._TOS and _G._TOS.version or "?"), D.c("title")) end
  C.cls = function() redraw() end
  C.clear = C.cls
  C.whoami = function() o(who) end
  C.echo = function(a) o(table.concat(a, " ")) end

  -- ── File commands ──────────────────────────────────────
  C.touch = function(a)
    if not a[1] then o("touch <file>"); return end
    local p = rp(a[1])
    if F.exists(p) then o("Exists"); return end
    if F.writeFile(p, "") then o("Created", D.c("highlight"))
    else o("Failed", D.c("error")) end
  end

  C.cd = function(a)
    if not a[1] then o(cwd); return end
    local t = a[1]
    if t == "~" then
      t = "/home/" .. who
    elseif t == ".." then
      t = cwd:match("^(.*)/[^/]+/?$") or "/"
    else
      t = rp(t)
    end
    if t == "" then t = "/" end
    if F.isDirectory(t) then cwd = t else o("Not a directory", D.c("error")) end
  end

  C.ls = function(a)
    local p = rp(a[1] or cwd)
    local ok, l = pcall(F.list, p); if not ok then o("Cannot list", D.c("error")); return end
    local e = {}
    if type(l) == "table" then for _, n in ipairs(l) do e[#e+1] = n end
    elseif type(l) == "function" then for n in l do e[#e+1] = n end end
    table.sort(e, function(a2,b) local ad,bd = a2:sub(-1)=="/", b:sub(-1)=="/"
      if ad ~= bd then return ad end return a2 < b end)
    for _, n in ipairs(e) do
      if n:sub(-1) == "/" then o("  ["..n:sub(1,-2).."]", D.c("dir"))
      else o("  "..n) end
    end
    o(#e .. " items", D.c("dim"))
  end
  C.dir = C.ls

  C.cat = function(a)
    if not a[1] then o("cat <file>"); return end
    local c = F.readFile(rp(a[1]))
    if c then for l in c:gmatch("([^\n]*)\n?") do o(l) end
    else o("Cannot read", D.c("error")) end
  end
  C.type = C.cat

  C.more = C.cat  -- In CLI mode, more = cat (no viewer tabs)

  C.mkdir = function(a)
    if a[1] and F.makeDirectory(rp(a[1])) then o("Created", D.c("highlight"))
    else o("Usage: mkdir <dir> / Failed", D.c("error")) end
  end

  C.rm = function(a)
    if not a[1] then o("rm <path>"); return end
    local p = rp(a[1])
    if p:match("^/tos") then o("Protected", D.c("error")); return end
    if F.remove(p) then o("Removed", D.c("highlight")) else o("Failed", D.c("error")) end
  end

  C.cp = function(a)
    if not a[2] then o("cp <src> <dst>"); return end
    local ok2, err2 = F.copy(rp(a[1]), rp(a[2]))
    if ok2 then o("Copied", D.c("highlight"))
    else o(err2 or "Failed", D.c("error")) end
  end

  C.mv = function(a)
    if not a[2] then o("mv <src> <dst>"); return end
    if F.rename(rp(a[1]), rp(a[2])) then o("Moved", D.c("highlight"))
    else o("Failed", D.c("error")) end
  end

  C.find = function(a)
    local root, pattern = "/", nil
    local i = 1
    while i <= #a do
      if a[i] == "-name" and a[i+1] then pattern = a[i+1]; i = i + 2
      else root = rp(a[i]); i = i + 1 end
    end
    local results = {}
    local function scan(dir)
      local ok2, list = pcall(F.list, dir)
      if not ok2 or not list then return end
      local items = {}
      if type(list) == "table" then items = list
      elseif type(list) == "function" then for n in list do items[#items+1] = n end end
      for _, n in ipairs(items) do
        local full = F.join(dir, n:gsub("/$",""))
        local isDir = n:sub(-1) == "/"
        if not pattern or full:match(pattern) or n:match(pattern) then
          results[#results+1] = { full .. (isDir and "/" or ""), isDir }
        end
        if isDir and not full:match("^/tos") then scan(full) end
      end
    end
    scan(root)
    for _, r in ipairs(results) do o(r[1], r[2] and D.c("highlight") or nil) end
    o(#results .. " result(s)", D.c("dim"))
  end

  C.grep = function(a)
    if not a[2] then o("grep <pattern> <file>"); return end
    local content = F.readFile(rp(a[2]))
    if not content then o("Cannot read", D.c("error")); return end
    local count, ln = 0, 0
    for line in content:gmatch("([^\n]*)\n?") do
      ln = ln + 1
      if line:find(a[1], 1, true) then o(string.format("%4d: %s", ln, line)); count = count + 1 end
    end
    o(count > 0 and (count .. " match(es)") or "No matches", D.c("dim"))
  end

  C.wc = function(a)
    if not a[1] then o("wc <file>"); return end
    local content = F.readFile(rp(a[1]))
    if not content then o("Cannot read", D.c("error")); return end
    local lines, words = 0, 0
    for line in content:gmatch("([^\n]*)\n?") do
      lines = lines + 1
      for _ in line:gmatch("%S+") do words = words + 1 end
    end
    o(string.format("Lines: %d  Words: %d  Bytes: %d", lines, words, #content))
  end

  -- ── System info ────────────────────────────────────────
  C.mem = function()
    local fr, tot = computer.freeMemory(), computer.totalMemory()
    o(string.format("RAM: %dK / %dK (%d%% free)",
      math.floor(fr/1024), math.floor(tot/1024), math.floor(fr/tot*100)))
  end

  C.hw = function()
    local seen = {}
    for addr, ctype in comp.list() do seen[ctype] = (seen[ctype] or 0) + 1 end
    for ctype, n in pairs(seen) do o(string.format("  %-20s x%d", ctype, n)) end
  end

  C.ps = function()
    if not P then o("Process manager unavailable", D.c("error")); return end
    local list = P.list and P.list() or {}
    if #list == 0 then o("(no processes)"); return end
    o(string.format("  %3s  %-12s  %-7s  %s", "PID", "NAME", "STATE", "DSP"))
    for _, p in ipairs(list) do
      o(string.format("  %3s  %-12s  %-7s  %s",
        tostring(p.pid or "?"), tostring(p.name or "?"),
        tostring(p.state or ""), tostring(p.display or "-")))
    end
  end

  C.kill = function(a)
    if not a[1] then o("kill <pid>"); return end
    if not P then o("Process manager unavailable", D.c("error")); return end
    local pid = tonumber(a[1])
    if pid then
      local ok2, err = P.kill(pid)
      if ok2 then o("Killed PID " .. pid, D.c("highlight")) else o(tostring(err), D.c("error")) end
    else o("Invalid PID", D.c("error")) end
  end

  C.fg = function(a)
    if not a[1] then o("fg <pid>"); return end
    if not P then return end
    local pid = tonumber(a[1])
    if not pid or not P.get(pid) then o("No such process", D.c("error")); return end
    P.setForeground(pid, myDisplayIdx)
    o("Foreground: PID " .. pid, D.c("highlight"))
  end

  C.df = function()
    if not F.mounts then o("VFS unavailable", D.c("error")); return end
    local ok, mnts = pcall(F.mounts)
    if not ok then o("Error: " .. tostring(mnts), D.c("error")); return end
    for _, m in ipairs(mnts) do
      local tot = m.total or 0; local used = m.used or 0
      o(string.format("%-12s %5dK used %5dK free",
        tostring(m.mountPoint or "?"), math.floor(used/1024), math.floor((tot-used)/1024)))
    end
  end

  C.uptime = function()
    local up = K.uptime()
    o(string.format("Uptime: %dh %dm %ds", math.floor(up/3600), math.floor((up%3600)/60), math.floor(up%60)))
  end

  C.log = function(a)
    local logMod = K.getLog()
    if not logMod then o("Logger unavailable", D.c("error")); return end
    local count = tonumber(a and a[1]) or 20
    local entries = logMod.recent(count)
    for _, e in ipairs(entries) do o(logMod.format(e)) end
    if #entries == 0 then o("(no entries)") end
  end

  C.verify = function()
    local files = {
      "/tos/kernel/init.lua", "/tos/kernel/log.lua", "/tos/kernel/hal.lua",
      "/tos/kernel/event.lua", "/tos/kernel/process.lua", "/tos/kernel/fs.lua",
      "/tos/kernel/display.lua", "/tos/shell/init.lua",
    }
    local missing = 0
    for _, path in ipairs(files) do
      if F.exists(path) then o("  OK  " .. path, D.c("highlight"))
      else o("  !!  " .. path, D.c("error")); missing = missing + 1 end
    end
    o(missing == 0 and "All files OK." or (missing .. " missing!"), missing == 0 and D.c("highlight") or D.c("error"))
  end

  C.programs = function()
    local dirs = { "/bin", "/usr/bin", "/home/" .. who }
    for _, dir in ipairs(dirs) do
      if F.isDirectory(dir) then
        local ok2, list = pcall(F.list, dir)
        if ok2 and list then
          local items = {}
          if type(list) == "table" then items = list
          elseif type(list) == "function" then for n in list do items[#items+1] = n end end
          local found = {}
          for _, n in ipairs(items) do if n:match("%.lua$") then found[#found+1] = n end end
          if #found > 0 then
            o(" " .. dir .. ":", D.c("dim"))
            for _, n in ipairs(found) do o("   " .. n, D.c("highlight")) end
          end
        end
      end
    end
  end

  C.history = function()
    if #hi == 0 then o("(empty)"); return end
    for i, h in ipairs(hi) do o(string.format("%3d  %s", i, h)) end
  end

  C.about = function()
    o("TOS - Terminal Operating System", D.c("title"))
    o("By Discover Interactive", D.c("highlight"))
    o("License: GNU GPL v3.0", D.c("dim"))
    o("Type 'ver' for version info.", D.c("dim"))
  end

  C.tutorial = function()
    local ok2, tut = pcall(require, "shell.tutorial")
    if not ok2 then o("Tutorial unavailable", D.c("error")); return end
    tut.run({ D = D, F = F, U = U, st = st, W = W, H = H })
    redraw()
  end

  -- ── Execution ──────────────────────────────────────────
  C.run = function(a)
    if not a[1] then o("run <file.lua> [args]"); return end
    local path = rp(a[1])
    local data = F.readFile(path)
    if not data then o("Cannot read: " .. a[1], D.c("error")); return end
    -- Build a sandboxed environment — no ambient _G access.
    local ok1, sandbox = pcall(require, "kernel.sandbox")
    if not ok1 then o("Sandbox unavailable", D.c("error")); return end
    local env = sandbox.build{
      name    = a[1],
      cwd     = cwd,
      session = (U and U.currentSession and U.currentSession()) or nil,
      caps    = {
        ["fs.read"]  = true,
        ["fs.write"] = true,
        ["compat.io"] = true,
      },
      stdout  = function(line) o(line) end,
    }
    local fn, err = load(data, "=" .. a[1], "t", env)
    if not fn then o("Error: " .. tostring(err), D.c("error")); return end
    local runArgs = {}
    for i = 2, #a do runArgs[#runArgs+1] = a[i] end
    local ok2, result = pcall(fn, table.unpack(runArgs))
    if not ok2 then o("Error: " .. tostring(result), D.c("error"))
    elseif result ~= nil then o(tostring(result)) end
  end

  C.bg = function(a)
    o("Background tasks require the TUI. Use 'tui' first, or 'run' for foreground.", D.c("dim"))
  end

  C.edit = function(a)
    o("Editor requires the TUI. Use 'tui' then 'edit " .. (a[1] or "<file>") .. "'.", D.c("dim"))
  end

  C.lua = function()
    o("Lua REPL requires the TUI. Use 'tui' then 'lua'.", D.c("dim"))
  end

  -- ── User management ────────────────────────────────────
  C.passwd = function()
    if not U then o("No user system", D.c("error")); return end
    o("Enter current password:"); local old = ""
    -- Simple password read in CLI
    local function readPass()
      local buf = ""
      while true do
        D.fill(1, cy, W, 1, " ", D.c("fg"), D.c("bg"))
        D.set(1, cy, string.rep("*", #buf) .. "_", D.c("fg"), D.c("bg"))
        local sg, _, ch, co = pullSignal()
        if sg == "key_down" then
          if co == 28 then cy = cy + 1; return buf
          elseif co == 14 then if #buf > 0 then buf = buf:sub(1,-2) end
          elseif ch and ch >= 32 and ch < 127 then buf = buf .. string.char(ch) end
        end
      end
    end
    scr(); local old2 = readPass()
    o("Enter new password:"); scr(); local new2 = readPass()
    local ok2, err2 = U.changePassword(who, who, old2, new2)
    if ok2 then o("Password changed.", D.c("highlight"))
    else o(tostring(err2), D.c("error")) end
  end

  C.users = function()
    if not U then o("No user system", D.c("error")); return end
    if userTier < 2 then o("Admin required", D.c("error")); return end
    local list = U.list and U.list() or {}
    for _, u in ipairs(list) do
      o(string.format("  %-12s tier=%d %s",
        u.username or "?", u.tier or 0, u.locked and "LOCKED" or ""))
    end
  end

  C.useradd = function(a)
    if not U then o("No user system", D.c("error")); return end
    if userTier < 3 then o("Root required", D.c("error")); return end
    if not a[1] then o("useradd <username>"); return end
    o("Password for " .. a[1] .. ":"); scr()
    local function readPass()
      local buf = ""
      while true do
        D.fill(1, cy, W, 1, " ", D.c("fg"), D.c("bg"))
        D.set(1, cy, string.rep("*", #buf) .. "_", D.c("fg"), D.c("bg"))
        local sg, _, ch, co = pullSignal()
        if sg == "key_down" then
          if co == 28 then cy = cy + 1; return buf
          elseif co == 14 then if #buf > 0 then buf = buf:sub(1,-2) end
          elseif ch and ch >= 32 and ch < 127 then buf = buf .. string.char(ch) end
        end
      end
    end
    local pass = readPass()
    local ok2, err2 = U.create("root", a[1], pass, 1)
    if ok2 then o("User '" .. a[1] .. "' created.", D.c("highlight"))
    else o(tostring(err2), D.c("error")) end
  end

  C.userdel = function(a)
    if not U then o("No user system", D.c("error")); return end
    if userTier < 3 then o("Root required", D.c("error")); return end
    if not a[1] then o("userdel <username>"); return end
    local ok2, err2 = U.delete("root", a[1])
    if ok2 then o("Deleted: " .. a[1], D.c("highlight"))
    else o(tostring(err2), D.c("error")) end
  end

  C.usermod = function(a)
    if not U then o("No user system", D.c("error")); return end
    if userTier < 3 then o("Root required", D.c("error")); return end
    if not a[1] or not a[2] then o("usermod <user> lock|unlock|admin|user"); return end
    local ok2, err2
    if a[2] == "lock" then ok2, err2 = U.setLocked("root", a[1], true)
    elseif a[2] == "unlock" then ok2, err2 = U.setLocked("root", a[1], false)
    elseif a[2] == "admin" then ok2, err2 = U.setTier("root", a[1], 2)
    elseif a[2] == "user" then ok2, err2 = U.setTier("root", a[1], 1)
    else o("Valid: lock, unlock, admin, user"); return end
    if ok2 then o("Done.", D.c("highlight")) else o(tostring(err2), D.c("error")) end
  end

  -- ── Devices ────────────────────────────────────────────
  C.lsdev = function()
    local count = 0
    for addr, ctype in comp.list() do
      o(string.format("  %-16s %s", ctype, addr:sub(1,8) .. "..."))
      count = count + 1
    end
    if count == 0 then o("(no peripherals)") end
  end

  C.mount = function(a)
    if a[1] and a[2] then
      local found
      for addr in comp.list("filesystem") do
        if addr:sub(1,#a[1]) == a[1] then found = addr; break end
      end
      if not found then o("Device not found", D.c("error")); return end
      local mnt = a[2]:sub(1,1) == "/" and a[2] or ("/" .. a[2])
      local ok2, px = pcall(comp.proxy, found)
      if not ok2 then o("Cannot proxy", D.c("error")); return end
      if not F.exists(mnt) then pcall(F.makeDirectory, mnt) end
      F.mount(mnt, px)
      o("Mounted at " .. mnt, D.c("highlight"))
    else
      if not F.mounts then o("VFS unavailable", D.c("error")); return end
      local mnts = F.mounts()
      for _, m in ipairs(mnts) do o(string.format("  %-16s %s", m.mountPoint or "?", m.label or "")) end
    end
  end

  C.umount = function(a)
    if not a[1] then o("umount <mountpoint>"); return end
    local mnt = a[1]:sub(1,1) == "/" and a[1] or ("/" .. a[1])
    local ok2, err2 = F.unmount(mnt)
    if ok2 then o("Unmounted", D.c("highlight")) else o(tostring(err2 or "Failed"), D.c("error")) end
  end

  -- ── Environment ────────────────────────────────────────
  C.env = function(a)
    local ok2, envMod = pcall(require, "kernel.env")
    if not ok2 then o("Env unavailable", D.c("error")); return end
    if a[1] then
      local k, v = a[1]:match("^([%w_]+)=(.*)$")
      if k then envMod.write(nil, k, v); o(k .. "=" .. v, D.c("highlight"))
      else o(a[1] .. "=" .. tostring(envMod.read(nil, a[1]) or "")) end
    else
      for k, v in pairs(envMod.list(nil)) do o("  " .. k .. "=" .. tostring(v)) end
    end
  end
  C.export = C.env
  C.set = C.env

  -- ── Services & Cron ────────────────────────────────────
  C.service = function(a)
    if userTier < 2 then o("Admin required", D.c("error")); return end
    local ok2, rc = pcall(require, "kernel.rc")
    if not ok2 then o("RC unavailable", D.c("error")); return end
    if not a[1] then
      for _, s in ipairs(rc.list()) do
        o(string.format("  %-16s %s", s.name, s.running and "running" or "stopped"),
          s.running and D.c("highlight") or D.c("dim"))
      end
    elseif a[1] == "start" and a[2] then
      local ok3, err = rc.start(a[2])
      o(ok3 and ("Started: " .. a[2]) or tostring(err), ok3 and D.c("highlight") or D.c("error"))
    elseif a[1] == "stop" and a[2] then
      local ok3, err = rc.stop(a[2])
      o(ok3 and ("Stopped: " .. a[2]) or tostring(err), ok3 and D.c("highlight") or D.c("error"))
    else o("service [start|stop <name>]") end
  end

  C.cron = function(a)
    if userTier < 2 then o("Admin required", D.c("error")); return end
    local ok2, cronMod = pcall(require, "kernel.cron")
    if not ok2 then o("Cron unavailable", D.c("error")); return end
    if not a[1] or a[1] == "list" then
      local jobs = cronMod.list()
      if #jobs == 0 then o("No jobs"); return end
      for _, j in ipairs(jobs) do
        o(string.format("  #%d %-12s %ss %s", j.id, j.name:sub(1,12), j.interval, j.enabled and "on" or "off"))
      end
    elseif a[1] == "add" and a[2] and a[3] and a[4] then
      local id = cronMod.add(a[2], tonumber(a[3]), table.concat(a, " ", 4))
      o("Added job #" .. id, D.c("highlight"))
    elseif a[1] == "rm" and a[2] then
      cronMod.remove(tonumber(a[2])); o("Removed", D.c("highlight"))
    else o("cron [list|add <name> <sec> <script>|rm <id>]") end
  end

  -- ── Peripherals ────────────────────────────────────────
  C.redstone = function(a)
    local ok2, rs = pcall(require, "peripheral.redstone")
    if not ok2 then o("No redstone", D.c("error")); return end
    if not a[1] then
      local st2 = rs.status()
      if not st2 then o("No redstone component", D.c("error")); return end
      for _, s in ipairs(st2) do o(string.format("  %-9s in=%2d out=%2d", s.name, s.input, s.output)) end
    elseif a[1] == "set" and a[2] and a[3] then
      local ok3, err = rs.setOutput(a[2], tonumber(a[3]) or 15)
      o(ok3 and ("Set " .. a[2] .. "=" .. a[3]) or tostring(err), ok3 and D.c("highlight") or D.c("error"))
    elseif a[1] == "pulse" and a[2] then
      rs.pulse(a[2], tonumber(a[3]) or 0.5); o("Pulsed " .. a[2], D.c("highlight"))
    else o("redstone [set <side> <0-15>|pulse <side>]") end
  end
  C.rs = C.redstone

  C.robot = function(a)
    local ok2, rob = pcall(require, "peripheral.robot")
    if not ok2 then o("No robot module", D.c("error")); return end
    if not rob.available() then o("Not a robot", D.c("error")); return end
    local cmd = a[1]
    if not cmd then o("robot <fwd|back|up|down|left|right|swing|use|detect|inv>"); return end
    if cmd == "forward" or cmd == "fwd" then local ok3, r = rob.forward(); o(ok3 and "Forward" or tostring(r), ok3 and D.c("highlight") or D.c("error"))
    elseif cmd == "back" then local ok3, r = rob.back(); o(ok3 and "Back" or tostring(r), ok3 and D.c("highlight") or D.c("error"))
    elseif cmd == "up" then local ok3, r = rob.up(); o(ok3 and "Up" or tostring(r), ok3 and D.c("highlight") or D.c("error"))
    elseif cmd == "down" then local ok3, r = rob.down(); o(ok3 and "Down" or tostring(r), ok3 and D.c("highlight") or D.c("error"))
    elseif cmd == "left" then rob.turnLeft(); o("Left", D.c("highlight"))
    elseif cmd == "right" then rob.turnRight(); o("Right", D.c("highlight"))
    elseif cmd == "swing" then local ok3, r = rob.swing(a[2]); o(ok3 and "Swing" or tostring(r))
    elseif cmd == "use" then local ok3, r = rob.use(a[2]); o(ok3 and "Used" or tostring(r))
    elseif cmd == "detect" then local ok3, r = rob.detect(a[2]); o(ok3 and ("Block: " .. tostring(r)) or "Nothing")
    else o("Unknown: " .. cmd, D.c("error")) end
  end

  C.inventory = function(a)
    local ok2, inv = pcall(require, "peripheral.inventory")
    if not ok2 then o("No inventory module", D.c("error")); return end
    if not inv.available() then o("No inventory controller", D.c("error")); return end
    local side = a[1] and (tonumber(a[1]) or a[1]) or nil
    local items = inv.list(side)
    if items then
      for _, item in ipairs(items) do
        if item.count > 0 then o(string.format("  [%2d] %dx %s", item.slot, item.count, item.name or "?")) end
      end
    else o("Cannot read inventory", D.c("error")) end
  end
  C.inv = C.inventory

  C.component = function(a)
    if userTier < 2 then o("Admin required", D.c("error")); return end
    if not a[1] then o("component <type> [method] [args]"); return end
    if a[1] == "list" then
      local seen = {}
      for addr, ctype in comp.list() do seen[ctype] = (seen[ctype] or 0) + 1 end
      for ctype, cnt in pairs(seen) do o(string.format("  %-20s x%d", ctype, cnt)) end
      return
    end
    local proxy = comp.proxy(comp.list(a[1])() or "")
    if not proxy then o("No component: " .. a[1], D.c("error")); return end
    if not a[2] then
      local methods = {}
      for k, v in pairs(proxy) do if type(v) == "function" then methods[#methods+1] = k end end
      table.sort(methods)
      for _, m in ipairs(methods) do o("  " .. m .. "()") end
    else
      local method = proxy[a[2]]
      if not method then o("Unknown method: " .. a[2], D.c("error")); return end
      local args2 = {}
      for i = 3, #a do
        local v = a[i]
        if v == "true" then args2[#args2+1] = true
        elseif v == "false" then args2[#args2+1] = false
        elseif tonumber(v) then args2[#args2+1] = tonumber(v)
        else args2[#args2+1] = v end
      end
      local results = table.pack(pcall(method, table.unpack(args2)))
      if results[1] then for i = 2, results.n do o("  " .. tostring(results[i])) end
      else o("Error: " .. tostring(results[2]), D.c("error")) end
    end
  end

  -- ── Network ────────────────────────────────────────────
  local function netExt(name)
    return function(a)
      if not NM then o("No network", D.c("error")); return end
      local ok2, m2 = pcall(require, "shell.ext")
      if ok2 and m2[name] then
        m2[name](a, { K=K, E=E, P=P, F=F, D=D, U=U,
          o=function(t,c) o(tostring(t), c) end, st=st, computer=computer, cwd=cwd })
      else o("Extension unavailable", D.c("error")) end
    end
  end
  for _, n in ipairs({ "net", "ping", "hostname", "device", "config", "battery", "audio" }) do
    C[n] = netExt(n)
  end

  C.chat = function(a)
    if not NM then o("No network", D.c("error")); return end
    local ok2, chatMod = pcall(require, "shell.chat")
    if not ok2 then o("Chat unavailable", D.c("error")); return end
    chatMod.run(K, st)
    redraw()
  end

  C.rsh = function(a)
    if userTier < 2 then o("Admin required", D.c("error")); return end
    if not a[1] or not a[2] then o("rsh <address> <command>"); return end
    if not NM then o("No network", D.c("error")); return end
    local ok2, remoteMod = pcall(require, "kernel.net.remote")
    if not ok2 then o("Remote unavailable", D.c("error")); return end
    local result, err = remoteMod.execute(a[1], table.concat(a, " ", 2))
    if result then o(result) else o("Error: " .. tostring(err), D.c("error")) end
  end

  C.scp = function(a)
    if userTier < 2 then o("Admin required", D.c("error")); return end
    if not a[1] or not a[2] then o("scp <addr>:<path> <local>"); return end
    if not NM then o("No network", D.c("error")); return end
    local ok2, transferMod = pcall(require, "kernel.net.transfer")
    if not ok2 then o("Transfer unavailable", D.c("error")); return end
    local addr, rpath = a[1]:match("^([^:]+):(.+)$")
    if addr then
      local lpath = rp(a[2])
      local ok3, err = transferMod.request(addr, rpath, lpath)
      if ok3 then o("Downloaded: " .. rpath, D.c("highlight"))
      else o("Failed: " .. tostring(err), D.c("error")) end
    else o("scp <addr>:<path> <local>") end
  end

  C.screen = function(a)
    local ok2, screenMod = pcall(require, "kernel.screen")
    if not ok2 then o("Screen unavailable", D.c("error")); return end
    if not a[1] or a[1] == "list" then
      for _, s in ipairs(screenMod.list()) do
        o(string.format("  %s%d: %s (%dx%d)", s.active and "*" or " ", s.index, s.label, s.w, s.h))
      end
    elseif a[1] == "next" then screenMod.next(); o("Switched", D.c("highlight"))
    elseif tonumber(a[1]) then
      if screenMod.setActive(tonumber(a[1])) then o("Switched", D.c("highlight"))
      else o("Invalid index", D.c("error")) end
    else o("screen [list|next|<index>]") end
  end

  -- ── Modules & Disks ────────────────────────────────────
  C.mod = function(a)
    local ok2, modMgr = pcall(require, "kernel.modules")
    if not ok2 then o("Module system unavailable", D.c("error")); return end
    local sub = a[1]
    if not sub or sub == "list" then
      local mods = modMgr.list()
      if #mods == 0 then
        local scanned = modMgr.scan()
        if scanned > 0 then mods = modMgr.list() end
      end
      if #mods == 0 then o("No modules installed"); return end
      for _, m in ipairs(mods) do
        o(string.format("  %-14s %s %s", m.name:sub(1,14), m.version, m.enabled and "on" or "off"),
          m.enabled and D.c("highlight") or D.c("dim"))
      end
    elseif sub == "info" and a[2] then
      local entry = modMgr.get(a[2])
      if not entry then o("Not found: " .. a[2], D.c("error")); return end
      o("  Name: " .. entry.name); o("  Version: " .. entry.version)
      o("  Status: " .. (entry.enabled and "enabled" or "disabled"))
    elseif sub == "enable" and a[2] then
      if userTier < 2 then o("Admin required", D.c("error")); return end
      local ok3, err = modMgr.enable(a[2])
      o(ok3 and ("Enabled: " .. a[2]) or tostring(err), ok3 and D.c("highlight") or D.c("error"))
    elseif sub == "disable" and a[2] then
      if userTier < 2 then o("Admin required", D.c("error")); return end
      local ok3, err = modMgr.disable(a[2])
      o(ok3 and ("Disabled: " .. a[2]) or tostring(err), ok3 and D.c("highlight") or D.c("error"))
    elseif sub == "uninstall" and a[2] then
      if userTier < 2 then o("Admin required", D.c("error")); return end
      local ok3, err = modMgr.uninstall(a[2])
      o(ok3 and ("Uninstalled: " .. a[2]) or tostring(err), ok3 and D.c("highlight") or D.c("error"))
    elseif sub == "commands" then
      local cmds = modMgr.getCommands()
      local names = {}
      for n in pairs(cmds) do names[#names+1] = n end
      table.sort(names)
      for _, n in ipairs(names) do o("  " .. n) end
    elseif sub == "scan" then
      local found = modMgr.scan()
      o(found > 0 and ("Registered " .. found .. " module(s)") or "No new modules", D.c("highlight"))
    else o("mod [list|info|enable|disable|uninstall|scan|commands]") end
  end

  C.disk = function(a)
    local sub = a[1]
    if not sub or sub == "list" then
      local fsList = F.mounts and F.mounts() or {}
      local removable = {}
      for _, m in ipairs(fsList) do
        if m.mountPoint ~= "/" then removable[#removable+1] = m end
      end
      if #removable == 0 then o("No removable disks"); return end
      for _, m in ipairs(removable) do
        o(string.format("  %-16s %s", m.mountPoint or "?", m.label or ""))
      end
    elseif sub == "info" and a[2] then
      local mnt = F.normalize(a[2])
      if not F.isDirectory(mnt) then o("Not a mount point", D.c("error")); return end
      local hasModule = F.exists(F.join(mnt, "module.cfg"))
      local hasTOS = F.exists(F.join(mnt, "tos/kernel/init.lua"))
      o("  Mount: " .. mnt)
      o("  Type: " .. (hasModule and "module" or hasTOS and "TOS install" or "data"))
    elseif sub == "install" and a[2] then
      if userTier < 2 then o("Admin required", D.c("error")); return end
      local mnt = F.normalize(a[2])
      if not F.exists(F.join(mnt, "module.cfg")) then o("No module.cfg on disk", D.c("error")); return end
      local ok3, modMgr = pcall(require, "kernel.modules")
      if not ok3 then o("Module system unavailable", D.c("error")); return end
      local ok4, result = modMgr.install(mnt)
      o(ok4 and ("Installed: " .. tostring(result)) or ("Failed: " .. tostring(result)),
        ok4 and D.c("highlight") or D.c("error"))
    elseif sub == "eject" and a[2] then
      local ok3, err = F.unmount(a[2])
      o(ok3 and "Ejected" or tostring(err or "Failed"), ok3 and D.c("highlight") or D.c("error"))
    else o("disk [list|info|install|eject] <mount>") end
  end

  C.deploy = function(a)
    if userTier < 3 then o("Root required", D.c("error")); return end
    o("Deploy requires TUI. Use 'tui' then 'deploy'.", D.c("dim"))
  end

  C.compat = function()
    local ok2, compatMod = pcall(require, "compat")
    if not ok2 then o("Compat layer not loaded", D.c("error")); return end
    local mods = compatMod.list()
    for _, m in ipairs(mods) do
      o(string.format("  %-16s %s", m.name, m.loaded and "loaded" or "not loaded"),
        m.loaded and D.c("highlight") or D.c("dim"))
    end
  end

  -- ── System control ─────────────────────────────────────
  C.reboot   = function() K.reboot() end
  C.shutdown = function() K.shutdown() end
  C.logout   = function() E.push("tos_logout", myDisplayIdx) end

  C.tui = function()
    local ok, pm = pcall(require, "shell.panels")
    if not ok then o("panels.lua not available: " .. tostring(pm), D.c("error")); return end
    local code = pm.run({ K=K, E=E, P=P, F=F, D=D, U=U, SC=SC, NM=NM,
                          cwd=cwd, who=who, W=W, H=H, st=st })
    redraw()
    if code == "cli" then o("Returned to CLI.", D.c("dim")) end
  end

  redraw()
  o("TOS CLI Mode  |  type 'tui' to return to TUI", D.c("title"))
  o("")

  while true do
    scr()
    local host = SC and SC.get("hostname") or "tos"
    local pr   = who .. "@" .. host .. ":" .. cwd .. "$ "
    if #pr > W/2 then pr = who .. "$ " end
    D.fill(1, cy, W, 1, " ", D.c("fg"), D.c("bg"))
    D.set(1, cy, pr, D.c("highlight"), D.c("bg"))

    local buf = ""
    local hx  = #hi + 1

    while true do
      local px = #pr + 1
      D.fill(px, cy, W-px, 1, " ", D.c("fg"), D.c("bg"))
      local sh = #buf > W-px-1 and buf:sub(#buf-(W-px-2)) or buf
      D.set(px, cy, sh, D.c("fg"), D.c("bg"))
      D.set(px + #sh, cy, "_", D.c("highlight"), D.c("bg"))

      local sg, _, ch, co = pullSignal()
      if sg == "key_down" then
        if co == 28 then cy = cy + 1; if buf ~= "" then hi[#hi+1] = buf end; break
        elseif co == 14 then if #buf > 0 then buf = buf:sub(1,-2) end
        elseif co == 200 then if hx > 1 then hx = hx-1; buf = hi[hx] or "" end
        elseif co == 208 then
          if hx < #hi then hx = hx+1; buf = hi[hx] or "" else hx = #hi+1; buf = "" end
        elseif ch and ch >= 32 and ch < 127 then buf = buf .. string.char(ch) end
      elseif sg == "clipboard" and type(ch) == "string" then
        buf = buf .. ch:gsub("\n","")
      elseif sg == "tos_focus" then
        redraw(); buf = ""; break
      end
    end

    if buf ~= "" then
      local parts = {}
      for w in buf:gmatch("%S+") do parts[#parts+1] = w end
      local name = parts[1]:lower()
      local args = {}
      for i = 2, #parts do args[#args+1] = parts[i] end
      local fn = C[name]
      if not fn then
        -- Check module-provided commands
        local ok3, modMgr = pcall(require, "kernel.modules")
        if ok3 then
          local modCmd = modMgr.getCommand(name)
          if modCmd then
            fn = function(a)
              modCmd(a, function(t, c) o(tostring(t), c) end)
            end
          end
        end
      end
      if fn then
        local ok2, err2 = pcall(fn, args)
        if not ok2 then o("Error: " .. tostring(err2), D.c("error")) end
      else
        o("Unknown: " .. name .. " (try 'help')", D.c("error"))
      end
    end
  end
end

-- ── Entry point ──────────────────────────────────────────
function S.run(k, token)
  K = k;  st = token
  E = k.getEvent();  P = k.getProc()
  -- Use securefs so every user-initiated FS op goes through ACL checks.
  F = k.getSecureFS() or k.getFS();     D = k.getDisplay()
  U = k.getUsers();  SC = k.getConfig();  NM = k.getNet()
  -- Capture this seat's display index (nil on single-display / global kernel)
  local myDisplayIdx = k.getDisplayIdx and k.getDisplayIdx() or nil
  W, H = D.getSize()
  who = "root"
  if U and st then local s = U.getSession(st); if s then who = s.user end end
  cwd = "/home/" .. who
  if not F.exists(cwd) then cwd = "/" end

  -- Attempt to launch primary TUI
  local ok, pm = pcall(require, "shell.panels")
  if ok then
    local code = pm.run({ K=K, E=E, P=P, F=F, D=D, U=U, SC=SC, NM=NM,
                          cwd=cwd, who=who, W=W, H=H, st=st,
                          displayIdx=myDisplayIdx })
    if code ~= "cli" then return end  -- normal exit (reboot/shutdown/logout)
  else
    -- TUI failed to load — fall through to CLI
    D.clear(D.c("bg"))
    D.set(1, 2, "WARNING: TUI unavailable (" .. tostring(pm) .. ")", D.c("error"), D.c("bg"))
    D.set(1, 3, "Falling back to CLI mode.", D.c("warning"), D.c("bg"))
    computer.pullSignal(2)
  end

  -- CLI fallback (user chose Shell from quit menu, or TUI unavailable)
  cliLoop()
end

return S
